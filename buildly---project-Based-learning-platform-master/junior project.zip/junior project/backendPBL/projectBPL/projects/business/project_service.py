# projects/business/project_service.py
from django.utils import timezone  # ⭐ التصحيح هنا
from typing import Dict, Any, Optional, Tuple
from django.utils.translation import gettext_lazy as _
from django.db import IntegrityError
from projects.data.repositories import ProjectRepository
from projects.data.queries import ProjectQueries
from courses.data.repositories import CourseRepository

class ProjectService:
    """خدمة منطق الأعمال للمشاريع - فقط منطق الأعمال"""
    
    @staticmethod
    def validate_project_data(data: Dict[str, Any], course_id: int = None) -> Tuple[bool, Dict[str, Any]]:
        """التحقق من صحة بيانات المشروع"""
        errors = {}
        
        # التحقق من العنوان
        title = data.get('title', '').strip()
        if not title:
            errors['title'] = _('عنوان المشروع مطلوب')
        elif len(title) < 3:
            errors['title'] = _('العنوان يجب أن يكون 3 أحرف على الأقل')
        
        # التحقق من الوصف
        description = data.get('description', '').strip()
        if not description:
            errors['description'] = _('وصف المشروع مطلوب')
        elif len(description) < 20:
            errors['description'] = _('الوصف يجب أن يكون 20 حرفاً على الأقل')
        
        # التحقق من الوقت المقدر
        estimated_time = data.get('estimated_time')
        if estimated_time is None:
            errors['estimated_time'] = _('الوقت المقدر مطلوب')
        elif estimated_time <= 0:
            errors['estimated_time'] = _('الوقت يجب أن يكون أكبر من صفر')
        elif estimated_time > 500:
            errors['estimated_time'] = _('الوقت لا يمكن أن يتجاوز 500 ساعة')
        
        # التحقق من المستوى
        level = data.get('level')
        if not level:
            errors['level'] = _('مستوى المشروع مطلوب')
        
        # التحقق من لغة البرمجة
        language = data.get('language')
        if not language:
            errors['language'] = _('لغة البرمجة مطلوبة')
        
        return len(errors) == 0, errors
    
    @staticmethod
    def create_project(user, course_id: int, project_data: Dict[str, Any]) -> Tuple[bool, Optional[Dict[str, Any]], Optional[str]]:
        """إنشاء مشروع جديد"""
        try:
            # التحقق من صلاحية المستخدم
            if not user.is_admin:
                return False, None, _('يجب أن تكون مشرفاً لإنشاء مشروع')
            
            # الحصول على المسار
            course = CourseRepository.get_by_id(course_id)
            if not course:
                return False, None, _('المسار التعليمي غير موجود')
            
            # التحقق من صحة البيانات
            is_valid, errors = ProjectService.validate_project_data(project_data, course_id)
            if not is_valid:
                return False, errors, _('بيانات غير صالحة')
            
            # التحقق من عدم تكرار العنوان
            title = project_data.get('title', '').strip()
            if not ProjectQueries.check_title_availability(course_id, title):
                return False, {'title': _('يوجد بالفعل مشروع بهذا العنوان في هذا المسار')}, _('تعذر إنشاء المشروع')
            
            # إنشاء المشروع
            project = ProjectRepository.create_project(course, **project_data)
            
            # إعداد النتيجة
            result = {
                'project_id': project.id,
                'id': project.id,
                'course_id': project.course.id,
                'title': project.title,
                'description': project.description,
                'estimated_time': project.estimated_time,
                'level': project.level,
                'level_display': project.get_level_display(),
                'language': project.language,
                'language_display': project.get_language_display(),
                'order': project.order,
                'created_at': project.created_at,
            }
            
            return True, result, _('تم إنشاء المشروع بنجاح')
            
        except IntegrityError as e:
            if 'unique_project_title_per_course' in str(e):
                return False, {'title': _('يوجد بالفعل مشروع بهذا العنوان في هذا المسار')}, _('تعذر إنشاء المشروع')
            return False, None, str(e)
        except Exception as e:
            return False, None, str(e)
    
    @staticmethod
    def update_project(project_id: int, user, update_data: Dict[str, Any]) -> Tuple[bool, Optional[Dict[str, Any]], Optional[str]]:
        """تحديث مشروع موجود"""
        try:
            # التحقق من صلاحية المستخدم
            if not user.is_admin:
                return False, None, _('يجب أن تكون مشرفاً لتعديل المشروع')
            
            # الحصول على المشروع
            project = ProjectRepository.get_by_id(project_id)
            if not project:
                return False, None, _('المشروع غير موجود')
            
            # التحقق من صحة البيانات
            is_valid, errors = ProjectService.validate_project_data(update_data, project.course.id)
            if not is_valid:
                return False, errors, _('بيانات غير صالحة')
            
            # التحقق من عنوان المشروع
            new_title = update_data.get('title', project.title).strip()
            if new_title != project.title:
                if not ProjectQueries.check_title_availability(project.course.id, new_title, project_id):
                    return False, {'title': _('يوجد بالفعل مشروع بهذا العنوان في هذا المسار')}, _('تعذر تحديث المشروع')
            
            # تحديث المشروع
            updated_project = ProjectRepository.update_project(project, **update_data)
            
            # إعداد النتيجة
            result = {
                'project_id': updated_project.id,
                'id': updated_project.id,
                'course_id': updated_project.course.id,
                'title': updated_project.title,
                'description': updated_project.description,
                'estimated_time': updated_project.estimated_time,
                'level': updated_project.level,
                'level_display': updated_project.get_level_display(),
                'language': updated_project.language,
                'language_display': updated_project.get_language_display(),
                'order': updated_project.order,
                'updated_at': updated_project.updated_at,
            }
            
            return True, result, _('تم تحديث المشروع بنجاح')
            
        except IntegrityError as e:
            if 'unique_project_title_per_course' in str(e):
                return False, {'title': _('يوجد بالفعل مشروع بهذا العنوان في هذا المسار')}, _('تعذر تحديث المشروع')
            return False, None, str(e)
        except Exception as e:
            return False, None, str(e)
    
    @staticmethod
    def delete_project(project_id: int, user) -> Tuple[bool, Optional[Dict[str, Any]], Optional[str]]:
        """حذف مشروع"""
        try:
            # التحقق من صلاحية المستخدم
            if not user.is_admin:
                return False, None, _('يجب أن تكون مشرفاً لحذف المشروع')
            
            # الحصول على المشروع
            project = ProjectRepository.get_by_id(project_id)
            if not project:
                return False, None, _('المشروع غير موجود')
            
            # حذف المشروع
            deletion_result = ProjectRepository.delete_project(project)
            
            # إعداد النتيجة
            result = {
                'project_id': deletion_result['project_id'],
                'title': deletion_result['title'],
                'course_id': deletion_result['course_id'],
                'deleted_by': user.email,
                'deleted_at': timezone.now(),
            }
            
            return True, result, _('تم حذف المشروع بنجاح')
            
        except Exception as e:
            return False, None, str(e)
    
    @staticmethod
    def get_project_details(project_id: int, user) -> Tuple[bool, Optional[Dict[str, Any]], Optional[str]]:
        """الحصول على تفاصيل المشروع"""
        try:
            # الحصول على المشروع
            project = ProjectRepository.get_by_id(project_id)
            if not project:
                return False, None, _('المشروع غير موجود')
            
            # التحقق من صلاحية الوصول
            if not ProjectRepository.can_user_access_project(project, user):
                return False, None, _('ليس لديك صلاحية للوصول لهذا المشروع')
            
            # إعداد البيانات
            result = {
                'project_id': project.id,
                'id': project.id,
                'title': project.title,
                'description': project.description,
                'requirements': project.requirements,
                'objectives': project.objectives,
                'resources': project.resources,
                'estimated_time': project.estimated_time,
                'level': project.level,
                'level_display': project.get_level_display(),
                'language': project.language,
                'language_display': project.get_language_display(),
                'order': project.order,
                'is_active': project.is_active,
                'course_id': project.course.id,
                'course_title': project.course.title,
                'course': {
                    'id': project.course.id,
                    'title': project.course.title,
                    'instructor': {
                        'id': project.course.instructor.id,
                        'email': project.course.instructor.email,
                        'name': f"{project.course.instructor.first_name} {project.course.instructor.last_name}".strip(),
                    },
                },
                'created_at': project.created_at,
                'updated_at': project.updated_at,
            }
            
            return True, result, _('تم جلب بيانات المشروع بنجاح')
            
        except Exception as e:
            return False, None, str(e)
    
    @staticmethod
    def get_projects_list(user, course_id: int = None) -> Tuple[bool, Optional[list], Optional[str]]:
        """الحصول على قائمة المشاريع"""
        try:
            # الحصول على المشاريع المناسبة للمستخدم
            projects = ProjectQueries.get_projects_for_user(user, course_id)
            
            if not projects.exists():
                return True, [], _('لا توجد مشاريع متاحة')
            
            # إعداد البيانات
            result = []
            for project in projects:
                result.append({
                    'project_id': project.id,
                    'id': project.id,
                    'title': project.title,
                    'description': project.description,
                    'requirements': project.requirements,
                    'estimated_time': project.estimated_time,
                    'level': project.level,
                    'level_display': project.get_level_display(),
                    'language': project.language,
                    'language_display': project.get_language_display(),
                    'order': project.order,
                    'is_active': project.is_active,
                    'course_id': project.course.id,
                    'course_title': project.course.title,
                    'course': {
                        'id': project.course.id,
                        'title': project.course.title,
                        'instructor_name': f"{project.course.instructor.first_name} {project.course.instructor.last_name}".strip() or project.course.instructor.email,
                    },
                    'created_at': project.created_at,
                    'updated_at': project.updated_at,
                })
            
            return True, result, _('تم جلب المشاريع بنجاح')
            
        except Exception as e:
            return False, None, str(e)
    
    @staticmethod
    def get_course_projects_list(course_id: int, user) -> Tuple[bool, Optional[Dict[str, Any]], Optional[str]]:
        """الحصول على مشاريع مسار معين"""
        try:
            # الحصول على المسار
            course = CourseRepository.get_by_id(course_id)
            if not course:
                return False, None, _('المسار التعليمي غير موجود')
            
            # التحقق من صلاحية الوصول
            if not user.is_admin and (not course.is_public or not course.is_active):
                return False, None, _('ليس لديك صلاحية للوصول لهذا المسار')
            
            # الحصول على مشاريع المسار
            projects = ProjectQueries.get_course_projects(course_id, user)
            
            # إعداد النتيجة
            result = {
                'course': {
                    'id': course.id,
                    'title': course.title,
                    'instructor': f"{course.instructor.first_name} {course.instructor.last_name}".strip() or course.instructor.email,
                    'is_public': course.is_public,
                    'is_active': course.is_active,
                },
                'projects': []
            }
            
            if not projects.exists():
                result['message'] = _('لا توجد مشاريع في هذا المسار')
                result['has_projects'] = False
                return True, result, _('تم جلب معلومات المسار')
            
            # إضافة المشاريع
            for project in projects:
                result['projects'].append({
                    'id': project.id,
                    'title': project.title,
                    'description': project.description,
                    'estimated_time': project.estimated_time,
                    'level': project.get_level_display(),
                    'language': project.get_language_display(),
                    'order': project.order,
                    'created_at': project.created_at,
                })
            
            result['count'] = len(result['projects'])
            result['has_projects'] = True
            
            return True, result, _('تم جلب مشاريع المسار بنجاح')
            
        except Exception as e:
            return False, None, str(e)