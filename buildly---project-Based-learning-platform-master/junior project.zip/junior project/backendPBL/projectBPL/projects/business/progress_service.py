# projects/business/progress_service.py
from typing import Tuple, Optional, Dict, Any
from django.utils.translation import gettext_lazy as _
from projects.data.repositories import ProjectRepository

class ProgressService:
    """خدمة منطق الأعمال لتقدم المشاريع - فقط منطق الأعمال"""
    
    @staticmethod
    def can_start_project(project_id: int, user) -> Tuple[bool, Optional[Dict[str, Any]], Optional[str]]:
        """التحقق من إمكانية بدء المشروع"""
        try:
            # الحصول على المشروع
            project = ProjectRepository.get_by_id(project_id)
            if not project:
                return False, None, _('المشروع غير موجود')
            
            # التحقق من أن المستخدم متعلم
            if not hasattr(user, 'is_learner') or not user.is_learner:
                return False, None, _('فقط المتعلمين يمكنهم بدء المشاريع')
            
            # التحقق من أن المستخدم منضم للمسار
            course = ProjectRepository.get_project_course(project)
            if not course.enrolled_learners.filter(id=user.id).exists():
                return False, None, _('يجب الانضمام للمسار أولاً لبدء المشروع')
            
            # إعداد نتيجة التحقق
            result = {
                'can_start': True,
                'project': {
                    'id': project.id,
                    'title': project.title,
                    'description': project.description[:100] + '...',
                    'estimated_time': project.estimated_time,
                    'level': project.get_level_display(),
                    'language': project.get_language_display(),
                },
                'user': {
                    'id': user.id,
                    'email': user.email,
                    'name': f"{user.first_name} {user.last_name}".strip(),
                }
            }
            
            return True, result, _('يمكنك بدء المشروع')
            
        except Exception as e:
            return False, None, str(e)