# projects/admin.py
from django.contrib import admin
from projects.models.project import Project

admin.site.register(Project)