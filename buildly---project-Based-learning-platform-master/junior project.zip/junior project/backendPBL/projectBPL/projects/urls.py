
# projects/urls.py
from django.urls import path
from projects.api.views import (
    CreateProjectView,
    ListProjectsView,
    ProjectDetailView,
    CourseProjectsView,
    UpdateProjectView,
    DeleteProjectView,
    ConfirmDeleteProjectView,
    StartProjectView,
)

app_name = 'projects'

urlpatterns = [
    path('create/', CreateProjectView.as_view(), name='create-project'),
    path('<int:id>/update/', UpdateProjectView.as_view(), name='update-project'),
    path('<int:id>/confirm-delete/', ConfirmDeleteProjectView.as_view(), name='confirm-delete'),
    path('<int:id>/delete/', DeleteProjectView.as_view(), name='delete-project'),
    path('', ListProjectsView.as_view(), name='list-projects'),
    path('<int:id>/', ProjectDetailView.as_view(), name='project-detail'),
    path('course/<int:course_id>/', CourseProjectsView.as_view(), name='course-projects'),
    path('<int:id>/start/', StartProjectView.as_view(), name='start-project'),
]