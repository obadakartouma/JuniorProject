# projects/data/queries.py
from django.db.models import Q
from projects.models.project import Project

class ProjectQueries:
    """استعلامات معقدة خاصة بالمشاريع - فقط استعلامات"""
    
    @staticmethod
    def get_projects_for_user(user, course_id=None):
        """الحصول على المشاريع المتاحة للمستخدم"""
        if user.is_admin:
            queryset = Project.objects.filter(is_active=True)
        else:
            queryset = Project.objects.filter(
                course__is_public=True,
                course__is_active=True,
                is_active=True
            )
        
        if course_id:
            queryset = queryset.filter(course_id=course_id)
        
        return queryset.order_by('course', 'order')
    
    @staticmethod
    def get_course_projects(course_id, user):
        """الحصول على مشاريع مسار معين"""
        from courses.data.repositories import CourseRepository
        
        course = CourseRepository.get_by_id(course_id)
        if not course:
            return Project.objects.none()
        
        if user.is_admin:
            return Project.objects.filter(course=course, is_active=True)
        else:
            if course.is_public and course.is_active:
                return Project.objects.filter(course=course, is_active=True)
            return Project.objects.none()
    
    @staticmethod
    def check_title_availability(course_id, title, exclude_id=None):
        """التحقق من توفر العنوان للمشروع في مسار معين"""
        queryset = Project.objects.filter(
            course_id=course_id,
            title__iexact=title.strip(),
            is_active=True
        )
        
        if exclude_id:
            queryset = queryset.exclude(id=exclude_id)
        
        return not queryset.exists()
    
    @staticmethod
    def get_next_order_number(course_id):
        """الحصول على الرقم الترتيبي التالي للمشروع في المسار"""
        last_project = Project.objects.filter(
            course_id=course_id
        ).order_by('-order').first()
        
        return (last_project.order + 1) if last_project else 1