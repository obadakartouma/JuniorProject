# projects/data/repositories.py
from typing import Optional, List
from django.db import transaction
from django.utils import timezone  
from projects.models.project import Project

class ProjectRepository:
    """Repository Pattern للوصول إلى بيانات المشاريع - فقط عمليات CRUD"""
    
    @staticmethod
    def get_by_id(project_id: int) -> Optional[Project]:
        """الحصول على مشروع بواسطة ID"""
        try:
            return Project.objects.get(id=project_id, is_active=True)
        except Project.DoesNotExist:
            return None
    
    @staticmethod
    def get_all_active() -> List[Project]:
        """الحصول على جميع المشاريع النشطة"""
        return Project.objects.filter(is_active=True).order_by('course', 'order')
    
    @staticmethod
    @transaction.atomic
    def create_project(course, **kwargs) -> Project:
        """إنشاء مشروع جديد"""
        # تعيين الرقم الترتيبي إذا لم يكن محدداً
        if 'order' not in kwargs or not kwargs['order']:
            from .queries import ProjectQueries
            kwargs['order'] = ProjectQueries.get_next_order_number(course.id)
        
        # إنشاء المشروع
        project = Project.objects.create(course=course, **kwargs)
        return project
    
    @staticmethod
    @transaction.atomic
    def update_project(project: Project, **kwargs) -> Project:
        """تحديث بيانات المشروع"""
        for attr, value in kwargs.items():
            setattr(project, attr, value)
        project.save()
        return project
    
    @staticmethod
    @transaction.atomic
    def delete_project(project: Project):
        """حذف مشروع بشكل دائم"""
        course = project.course
        project_id = project.id
        project_title = project.title
        
        # حذف المشروع
        project.delete()
        
        return {
            'project_id': project_id,
            'title': project_title,
            'course_id': course.id
        }
    
    @staticmethod
    @transaction.atomic
    def soft_delete_project(project: Project) -> Project:
        """حذف مشروع بشكل ناعم (Soft Delete)"""
        project.is_active = False
        project.save()
        return project
    
    @staticmethod
    def get_project_course(project: Project):
        """الحصول على مسار المشروع"""
        return project.course
    
    @staticmethod
    def can_user_access_project(project: Project, user) -> bool:
        """التحقق من إمكانية وصول المستخدم للمشروع"""
        if user.is_admin:
            return True
        
        if not project.is_active:
            return False
        
        if not project.course.is_active:
            return False
        
        if project.course.is_public:
            return True
        
        # التحقق من انضمام المستخدم للمسار
        return project.course.enrolled_learners.filter(id=user.id).exists()