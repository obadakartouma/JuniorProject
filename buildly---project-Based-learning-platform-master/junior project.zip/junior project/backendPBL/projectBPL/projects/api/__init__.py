# projects/api/__init__.py
from .views import (
    CreateProjectView,
    ListProjectsView,
    ProjectDetailView,
    CourseProjectsView,
    UpdateProjectView,
    DeleteProjectView,
    ConfirmDeleteProjectView,
    StartProjectView,
)