# projects/api/serializers.py
from rest_framework import serializers
from django.utils.translation import gettext_lazy as _
from projects.models.project import Project

class ProjectCreateSerializer(serializers.ModelSerializer):
    """Serializer لإنشاء مشروع جديد - فقط تحقق من صحة البيانات الأساسية"""
    
    course_id = serializers.IntegerField(
        write_only=True,
        required=True,
        help_text='معرف المسار التعليمي (course_id)'
    )
    
    class Meta:
        model = Project
        fields = [
            'course_id', 'title', 'description', 'requirements',
            'objectives', 'resources', 'estimated_time',
            'level', 'language', 'order'
        ]
        extra_kwargs = {
            'title': {
                'required': True,
                'allow_blank': False,
                'error_messages': {
                    'required': _('عنوان المشروع مطلوب'),
                    'blank': _('عنوان المشروع لا يمكن أن يكون فارغاً')
                }
            },
            'description': {
                'required': True,
                'allow_blank': False,
                'error_messages': {
                    'required': _('وصف المشروع مطلوب'),
                    'blank': _('وصف المشروع لا يمكن أن يكون فارغاً')
                }
            },
            'estimated_time': {
                'required': True,
                'error_messages': {
                    'required': _('الوقت المقدر مطلوب'),
                    'invalid': _('الوقت يجب أن يكون رقم صحيح')
                }
            },
            'level': {
                'required': True,
                'error_messages': {
                    'required': _('مستوى المشروع مطلوب'),
                    'invalid_choice': _('المستوى المحدد غير صالح')
                }
            },
            'language': {
                'required': True,
                'error_messages': {
                    'required': _('لغة البرمجة مطلوبة'),
                    'invalid_choice': _('لغة البرمجة المحددة غير صالحة')
                }
            },
        }
    
    def validate_title(self, value):
        """تحقق أساسي من العنوان"""
        value = value.strip()
        if not value:
            raise serializers.ValidationError(_('عنوان المشروع مطلوب'))
        if len(value) < 3:
            raise serializers.ValidationError(_('العنوان يجب أن يكون 3 أحرف على الأقل'))
        return value
    
    def validate_description(self, value):
        """تحقق أساسي من الوصف"""
        value = value.strip()
        if len(value) < 20:
            raise serializers.ValidationError(_('الوصف يجب أن يكون على الأقل 20 حرفاً'))
        return value
    
    def validate_estimated_time(self, value):
        """تحقق أساسي من الوقت"""
        if value <= 0:
            raise serializers.ValidationError(_('الوقت المقدر يجب أن يكون أكبر من صفر'))
        if value > 500:
            raise serializers.ValidationError(_('الوقت المقدر لا يمكن أن يتجاوز 500 ساعة'))
        return value

class ProjectListSerializer(serializers.ModelSerializer):
    """Serializer لعرض قائمة المشاريع"""
    
    project_id = serializers.IntegerField(source='id')
    course_id = serializers.IntegerField(source='course.id')
    course_title = serializers.CharField(source='course.title')
    instructor_name = serializers.SerializerMethodField()
    level_display = serializers.CharField(source='get_level_display')
    language_display = serializers.CharField(source='get_language_display')
    
    class Meta:
        model = Project
        fields = [
            'project_id', 'course_id', 'course_title',
            'title', 'description', 'requirements',
            'objectives', 'resources', 'estimated_time',
            'level', 'level_display', 'language', 'language_display',
            'order', 'is_active', 'created_at', 'updated_at',
            'instructor_name'
        ]
    
    def get_instructor_name(self, obj):
        """الحصول على اسم مشرف المسار"""
        return f"{obj.course.instructor.first_name} {obj.course.instructor.last_name}"

class ProjectDetailSerializer(ProjectListSerializer):
    """Serializer لعرض تفاصيل مشروع معين"""
    
    class Meta(ProjectListSerializer.Meta):
        fields = ProjectListSerializer.Meta.fields + [
            # يمكن إضافة حقول إضافية للتفاصيل
        ]

class ProjectUpdateSerializer(serializers.ModelSerializer):
    """Serializer لتحديث مشروع موجود"""
    
    class Meta:
        model = Project
        fields = [
            'title', 'description', 'requirements', 'objectives',
            'resources', 'estimated_time', 'level', 'language', 'order'
        ]
        extra_kwargs = {
            'title': {
                'required': True,
                'allow_blank': False,
                'error_messages': {
                    'required': _('عنوان المشروع مطلوب'),
                    'blank': _('عنوان المشروع لا يمكن أن يكون فارغاً')
                }
            },
            'description': {
                'required': True,
                'allow_blank': False,
                'error_messages': {
                    'required': _('وصف المشروع مطلوب'),
                    'blank': _('وصف المشروع لا يمكن أن يكون فارغاً')
                }
            },
            'estimated_time': {
                'required': True,
                'error_messages': {
                    'required': _('الوقت المقدر مطلوب'),
                    'invalid': _('الوقت يجب أن يكون رقم صحيح')
                }
            },
            'level': {
                'required': True,
                'error_messages': {
                    'required': _('مستوى المشروع مطلوب'),
                    'invalid_choice': _('المستوى المحدد غير صالح')
                }
            },
            'language': {
                'required': True,
                'error_messages': {
                    'required': _('لغة البرمجة مطلوبة'),
                    'invalid_choice': _('لغة البرمجة المحددة غير صالحة')
                }
            },
        }

class ProjectDeleteConfirmationSerializer(serializers.ModelSerializer):
    """Serializer لعرض معلومات المشروع قبل الحذف"""
    
    course_info = serializers.SerializerMethodField()
    deletion_impact = serializers.SerializerMethodField()
    current_user = serializers.SerializerMethodField()
    
    class Meta:
        model = Project
        fields = [
            'id', 'title', 'description', 'requirements', 
            'objectives', 'estimated_time', 'level', 'language',
            'created_at', 'updated_at', 'course_info', 
            'deletion_impact', 'current_user'
        ]
        read_only_fields = fields
    
    def get_course_info(self, obj):
        return {
            'course_id': obj.course.id,
            'course_title': obj.course.title,
            'instructor': f"{obj.course.instructor.first_name} {obj.course.instructor.last_name}",
        }
    
    def get_deletion_impact(self, obj):
        return {
            'message': _('المشروع سيحذف بشكل دائم')
        }
    
    def get_current_user(self, obj):
        request = self.context.get('request')
        if request and request.user:
            return {
                'name': f"{request.user.first_name} {request.user.last_name}",
                'email': request.user.email,
                'role': 'مشرف' if request.user.is_admin else 'مستخدم'
            }
        return None