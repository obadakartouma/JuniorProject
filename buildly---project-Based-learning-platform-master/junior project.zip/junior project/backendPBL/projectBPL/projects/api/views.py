# projects/api/views.py
from rest_framework import permissions, status
from rest_framework.response import Response
from rest_framework.views import APIView
from django.utils.translation import gettext_lazy as _
from django.db import transaction
from projects.api.serializers import (
    ProjectCreateSerializer, ProjectUpdateSerializer, 
    ProjectDeleteConfirmationSerializer
)
from projects.business.project_service import ProjectService
from projects.business.progress_service import ProgressService

class IsAdminUser(permissions.BasePermission):
    """صلاحية المشرفين فقط"""
    def has_permission(self, request, view):
        return bool(request.user and request.user.is_authenticated and request.user.is_admin)

class CreateProjectView(APIView):
    """إنشاء مشروع جديد"""
    permission_classes = [permissions.IsAuthenticated, IsAdminUser]
    
    @transaction.atomic
    def post(self, request):
        serializer = ProjectCreateSerializer(data=request.data, context={'request': request})
        
        if not serializer.is_valid():
            return Response({
                'success': False,
                'message': _('بيانات غير صالحة'),
                'errors': serializer.errors,
            }, status=status.HTTP_400_BAD_REQUEST)
        
        # استخدام خدمة الأعمال لإنشاء المشروع
        course_id = serializer.validated_data.get('course_id')
        project_data = serializer.validated_data.copy()
        project_data.pop('course_id')  # إزالة course_id لأنه سيمرر بشكل منفصل
        
        success, result, message = ProjectService.create_project(
            request.user, 
            course_id,
            project_data
        )
        
        if success:
            return Response({
                'success': True,
                'message': message,
                'project': result
            }, status=status.HTTP_201_CREATED)
        else:
            return Response({
                'success': False,
                'message': message,
                'errors': result if result else None,
            }, status=status.HTTP_400_BAD_REQUEST)

class UpdateProjectView(APIView):
    """تحديث مشروع موجود"""
    permission_classes = [permissions.IsAuthenticated, IsAdminUser]
    
    def get(self, request, id):
        """الحصول على بيانات المشروع للتحديث"""
        success, result, message = ProjectService.get_project_details(id, request.user)
        
        if success:
            return Response({
                'success': True,
                'project': result
            })
        else:
            return Response({
                'success': False,
                'message': message
            }, status=status.HTTP_404_NOT_FOUND)

    @transaction.atomic
    def put(self, request, id):
        """تحديث المشروع"""
        serializer = ProjectUpdateSerializer(data=request.data)
        
        if not serializer.is_valid():
            return Response({
                'success': False,
                'message': _('بيانات غير صالحة'),
                'errors': serializer.errors,
            }, status=status.HTTP_400_BAD_REQUEST)
        
        # استخدام خدمة الأعمال لتحديث المشروع
        success, result, message = ProjectService.update_project(
            id, 
            request.user, 
            serializer.validated_data
        )
        
        if success:
            return Response({
                'success': True,
                'message': message,
                'project': result
            }, status=status.HTTP_200_OK)
        else:
            return Response({
                'success': False,
                'message': message,
                'errors': result if result else None,
            }, status=status.HTTP_400_BAD_REQUEST)

class DeleteProjectView(APIView):
    """حذف مشروع"""
    permission_classes = [permissions.IsAuthenticated, IsAdminUser]
    
    @transaction.atomic
    def delete(self, request, id):
        """حذف المشروع"""
        success, result, message = ProjectService.delete_project(id, request.user)
        
        if success:
            return Response({
                'success': True,
                'message': message,
                'deleted_project': result
            })
        else:
            return Response({
                'success': False,
                'message': message
            }, status=status.HTTP_400_BAD_REQUEST)

class ConfirmDeleteProjectView(APIView):
    """تأكيد حذف مشروع"""
    permission_classes = [permissions.IsAuthenticated, IsAdminUser]
    
    def get(self, request, id):
        """الحصول على تفاصيل المشروع للتأكيد"""
        success, result, message = ProjectService.get_project_details(id, request.user)
        
        if success:
            # إضافة بيانات التأكيد
            result['confirmation_message'] = _('هل أنت متأكد من حذف هذا المشروع؟')
            result['warning_message'] = _('تحذير: هذه العملية لا يمكن التراجع عنها')
            result['note'] = _('أنت على وشك حذف مشروع في مسار: ') + result['course']['title']
            result['current_user'] = request.user.email
            
            return Response({
                'success': True,
                'message': _('بيانات المشروع للتأكيد قبل الحذف'),
                'project': result,
                'confirmation_required': True
            })
        else:
            return Response({
                'success': False,
                'message': message
            }, status=status.HTTP_404_NOT_FOUND)

class ListProjectsView(APIView):
    """قائمة المشاريع"""
    permission_classes = [permissions.IsAuthenticated]
    
    def get(self, request):
        course_id = request.query_params.get('course_id')
        
        # استخدام خدمة الأعمال للحصول على قائمة المشاريع
        success, result, message = ProjectService.get_projects_list(request.user, course_id)
        
        return Response({
            'success': True,
            'message': message,
            'count': len(result) if result else 0,
            'projects': result if result else []
        })

class ProjectDetailView(APIView):
    """تفاصيل المشروع"""
    permission_classes = [permissions.IsAuthenticated]
    
    def get(self, request, id):
        success, result, message = ProjectService.get_project_details(id, request.user)
        
        if success:
            # إضافة معلومات إضافية
            from projects.models.project import Project
            additional_info = {
                'available_levels': dict(Project.LEVEL_CHOICES),
                'available_languages': dict(Project.PROGRAMMING_LANGUAGE_CHOICES),
                'can_edit': request.user.is_admin
            }
            
            return Response({
                'success': True,
                'message': message,
                'project': result,
                'additional_info': additional_info
            })
        else:
            return Response({
                'success': False,
                'message': message
            }, status=status.HTTP_400_BAD_REQUEST)

class CourseProjectsView(APIView):
    """مشاريع مسار معين"""
    permission_classes = [permissions.IsAuthenticated]
    
    def get(self, request, course_id):
        success, result, message = ProjectService.get_course_projects_list(course_id, request.user)
        
        if success:
            return Response({
                'success': True,
                'message': message,
                **result
            })
        else:
            status_code = status.HTTP_404_NOT_FOUND if 'غير موجود' in message else status.HTTP_403_FORBIDDEN
            return Response({
                'success': False,
                'message': message
            }, status=status_code)

class StartProjectView(APIView):
    """بدء المشروع"""
    permission_classes = [permissions.IsAuthenticated]
    
    def post(self, request, id):
        # استخدام خدمة الأعمال للتحقق من إمكانية بدء المشروع
        success, result, message = ProgressService.can_start_project(id, request.user)
        
        if success:
            return Response({
                'success': True,
                'message': _('🎉 تم بدء المشروع بنجاح!'),
                'project': result['project'],
                'instructions': _('يمكنك الآن البدء في تنفيذ المشروع'),
                'next_steps': [
                    _('1. اقرأ المتطلبات والأهداف'),
                    _('2. جهز البيئة اللازمة'),
                    _('3. ابدأ بتنفيذ الخطوات'),
                    _('4. اطلب المساعدة إذا احتجت')
                ]
            }, status=status.HTTP_200_OK)
        else:
            status_code = status.HTTP_404_NOT_FOUND
            if 'يجب الانضمام' in message:
                status_code = status.HTTP_400_BAD_REQUEST
            elif 'فقط المتعلمين' in message:
                status_code = status.HTTP_403_FORBIDDEN
            
            return Response({
                'success': False,
                'message': message
            }, status=status_code)