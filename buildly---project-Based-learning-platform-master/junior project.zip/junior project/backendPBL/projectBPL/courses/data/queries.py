# courses/data/queries.py
from django.db.models import Q, Count
from courses.models.course import Course

class CourseQueries:
    """استعلامات معقدة خاصة بالمسارات التعليمية - فقط استعلامات"""
    
    @staticmethod
    def get_active_courses_for_user(user):
        """الحصول على المسارات النشطة المتاحة للمستخدم"""
        if user.is_admin:
            return Course.objects.filter(is_active=True)
        else:
            return Course.objects.filter(
                is_active=True,
                is_public=True
            )
    
    @staticmethod
    def get_user_enrolled_courses(user):
        """الحصول على المسارات التي انضم إليها المستخدم"""
        return Course.objects.filter(
            enrolled_learners=user,
            is_active=True
        ).order_by('-created_at')
    
    @staticmethod
    def get_courses_by_instructor(instructor_id):
        """الحصول على مسارات مشرف معين"""
        return Course.objects.filter(
            instructor_id=instructor_id,
            is_active=True
        )
    
    @staticmethod
    def check_title_availability(title, exclude_id=None):
        """التحقق من توفر العنوان للمسار النشط"""
        queryset = Course.objects.filter(
            title__iexact=title.strip(),
            is_active=True
        )
        
        if exclude_id:
            queryset = queryset.exclude(id=exclude_id)
        
        return not queryset.exists()
    
    @staticmethod
    def get_courses_with_stats():
        """الحصول على المسارات مع إحصائياتها"""
        return Course.objects.filter(
            is_active=True
        ).annotate(
            enrolled_count=Count('enrolled_learners')
        )