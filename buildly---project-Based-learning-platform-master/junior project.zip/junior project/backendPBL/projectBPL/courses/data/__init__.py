# courses/data/__init__.py
from .queries import CourseQueries
from .repositories import CourseRepository