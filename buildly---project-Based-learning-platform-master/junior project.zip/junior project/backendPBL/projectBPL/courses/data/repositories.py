# courses/data/repositories.py
from typing import Optional, List
from django.db import transaction
from django.utils import timezone
from courses.models.course import Course

class CourseRepository:
    """Repository Pattern للوصول إلى بيانات المسارات - فقط عمليات CRUD"""
    
    @staticmethod
    def get_by_id(course_id: int) -> Optional[Course]:
        """الحصول على مسار بواسطة ID"""
        try:
            return Course.objects.get(id=course_id, is_active=True)
        except Course.DoesNotExist:
            return None
    
    @staticmethod
    def get_all_active() -> List[Course]:
        """الحصول على جميع المسارات النشطة"""
        return Course.objects.filter(is_active=True).order_by('-created_at')
    
    @staticmethod
    @transaction.atomic
    def create_course(instructor, **kwargs) -> Course:
        """إنشاء مسار جديد"""
        # التحقق من أن المنشئ هو مشرف
        if not instructor.is_admin:
            raise ValueError('يجب أن يكون منشئ المسار مشرفاً')
        
        # تعيين projects_count = 0 تلقائياً
        kwargs['projects_count'] = 0
        
        # إنشاء المسار
        course = Course.objects.create(instructor=instructor, **kwargs)
        
        # تنظيف قائمة المتعلمين
        course.enrolled_learners.clear()
        
        return course
    
    @staticmethod
    @transaction.atomic
    def update_course(course: Course, **kwargs) -> Course:
        """تحديث بيانات المسار"""
        for attr, value in kwargs.items():
            setattr(course, attr, value)
        course.save()
        return course
    
    @staticmethod
    @transaction.atomic
    def soft_delete_course(course: Course) -> Course:
        """حذف مسار بشكل ناعم (Soft Delete)"""
        course.is_active = False
        course.save()
        return course
    
    @staticmethod
    @transaction.atomic
    def add_learner_to_course(course: Course, user) -> bool:
        """إضافة متعلم للمسار"""
        if user.is_learner and not course.enrolled_learners.filter(id=user.id).exists():
            course.enrolled_learners.add(user)
            return True
        return False
    
    @staticmethod
    @transaction.atomic
    def remove_learner_from_course(course: Course, user) -> bool:
        """إزالة متعلم من المسار"""
        if user.is_learner and course.enrolled_learners.filter(id=user.id).exists():
            course.enrolled_learners.remove(user)
            return True
        return False
    
    @staticmethod
    def get_course_enrolled_learners(course: Course):
        """الحصول على قائمة المتعلمين المسجلين في المسار"""
        return course.enrolled_learners.all()
    
    @staticmethod
    def is_learner_enrolled(course: Course, user) -> bool:
        """التحقق من انضمام المتعلم للمسار"""
        return course.enrolled_learners.filter(id=user.id).exists()
    
    @staticmethod
    def update_projects_count(course: Course) -> int:
        """تحديث عدد المشاريع النشطة في المسار"""
        try:
            from projects.models import Project
            
            # حساب المشاريع النشطة فعليًا
            actual_count = Project.objects.filter(
                course=course,
                is_active=True
            ).count()
            
            # تحديث مباشر في قاعدة البيانات
            if course.projects_count != actual_count:
                Course.objects.filter(pk=course.pk).update(
                    projects_count=actual_count,
                    updated_at=timezone.now()
                )
                # تحديث نسخة الـ instance
                course.refresh_from_db()
                
            return actual_count
            
        except Exception:
            return 0
    
    @staticmethod
    def get_actual_projects_count(course: Course) -> int:
        """الحصول على العدد الحقيقي للمشاريع"""
        try:
            from projects.models import Project
            return Project.objects.filter(
                course=course,
                is_active=True
            ).count()
        except Exception:
            return 0