# courses/admin.py
from django.contrib import admin
from courses.models.course import Course

admin.site.register(Course)