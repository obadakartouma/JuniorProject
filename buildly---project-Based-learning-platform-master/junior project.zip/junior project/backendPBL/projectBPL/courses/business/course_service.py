# courses/business/course_service.py
from typing import Dict, Any, Optional, Tuple
from django.utils.translation import gettext_lazy as _
from django.db import IntegrityError
from courses.data.repositories import CourseRepository
from courses.data.queries import CourseQueries

class CourseService:
    """خدمة منطق الأعمال للمسارات التعليمية - فقط منطق الأعمال"""
    
    @staticmethod
    def validate_course_title(title: str, exclude_id: int = None) -> Tuple[bool, str]:
        """التحقق من صحة عنوان المسار"""
        title = title.strip()#
        
        if not title:
            return False, _('عنوان المسار مطلوب')
        
        if len(title) < 3:
            return False, _('العنوان يجب أن يكون 3 أحرف على الأقل')
        
        # التحقق من عدم التكرار
        if not CourseQueries.check_title_availability(title, exclude_id):
            return False, _('يوجد بالفعل مسار نشط بنفس العنوان')
        
        return True, ''
    
    @staticmethod
    def validate_course_description(description: str) -> Tuple[bool, str]:
        """التحقق من صحة وصف المسار"""
        description = description.strip()
        
        if not description:
            return False, _('وصف المسار مطلوب')
        
        if len(description) < 20:
            return False, _('الوصف يجب أن يكون 20 حرفاً على الأقل')
        
        return True, ''
    
    @staticmethod
    def validate_course_duration(duration: int) -> Tuple[bool, str]:
        """التحقق من صحة المدة المقدرة"""
        if duration is None:
            return False, _('المدة المقدرة مطلوبة')
        
        if duration <= 0:
            return False, _('المدة يجب أن تكون أكبر من صفر')
        
        if duration > 1000:
            return False, _('المدة لا يمكن أن تتجاوز 1000 ساعة')
        
        return True, ''
    
    @staticmethod
    def create_course(user, course_data: Dict[str, Any]) -> Tuple[bool, Optional[Dict[str, Any]], Optional[str]]:
        """إنشاء مسار جديد"""
        try:
            # التحقق من صلاحية المستخدم
            if not user.is_admin:
                return False, None, _('يجب أن تكون مشرفاً لإنشاء مسار')
            
            # التحقق من صحة البيانات
            title = course_data.get('title', '').strip()
            is_valid, error = CourseService.validate_course_title(title)
            if not is_valid:
                return False, {'title': error}, _('بيانات غير صالحة')
            
            description = course_data.get('description', '').strip()
            is_valid, error = CourseService.validate_course_description(description)
            if not is_valid:
                return False, {'description': error}, _('بيانات غير صالحة')
            
            duration = course_data.get('estimated_duration')
            is_valid, error = CourseService.validate_course_duration(duration)
            if not is_valid:
                return False, {'estimated_duration': error}, _('بيانات غير صالحة')
            
            # إنشاء المسار
            course = CourseRepository.create_course(user, **course_data)
            
            # إعداد النتيجة
            result = {
                'id': course.id,
                'title': course.title,
                'description': course.description,
                'level': course.get_level_display(),
                'category': course.get_category_display(),
                'estimated_duration': course.estimated_duration,
                'projects_count': course.projects_count,
                'is_public': course.is_public,
                'created_at': course.created_at,
            }
            
            return True, result, _('تم إنشاء المسار التعليمي بنجاح')
            
        except IntegrityError as e:
            if 'unique_course_title' in str(e):
                return False, {'title': _('يوجد بالفعل مسار نشط بنفس العنوان')}, _('تعذر إنشاء المسار')
            return False, None, str(e)
        except ValueError as e:
            return False, None, str(e)
        except Exception as e:
            return False, None, str(e)
    
    @staticmethod
    def update_course(course_id: int, user, update_data: Dict[str, Any]) -> Tuple[bool, Optional[Dict[str, Any]], Optional[str]]:
        """تحديث مسار موجود"""
        try:
            # التحقق من صلاحية المستخدم
            if not user.is_admin:
                return False, None, _('يجب أن تكون مشرفاً لتعديل المسار')
            
            # الحصول على المسار
            course = CourseRepository.get_by_id(course_id)
            if not course:
                return False, None, _('المسار غير موجود')
            
            # التحقق من صحة البيانات
            new_title = update_data.get('title', course.title).strip()
            if new_title != course.title:
                is_valid, error = CourseService.validate_course_title(new_title, course_id)
                if not is_valid:
                    return False, {'title': error}, _('بيانات غير صالحة')
            
            if 'description' in update_data:
                description = update_data['description'].strip()
                is_valid, error = CourseService.validate_course_description(description)
                if not is_valid:
                    return False, {'description': error}, _('بيانات غير صالحة')
            
            if 'estimated_duration' in update_data:
                duration = update_data['estimated_duration']
                is_valid, error = CourseService.validate_course_duration(duration)
                if not is_valid:
                    return False, {'estimated_duration': error}, _('بيانات غير صالحة')
            
            # تحديث المسار
            updated_course = CourseRepository.update_course(course, **update_data)
            
            # إعداد النتيجة
            result = {
                'id': updated_course.id,
                'title': updated_course.title,
                'description': updated_course.description,
                'level': updated_course.get_level_display(),
                'category': updated_course.get_category_display(),
                'estimated_duration': updated_course.estimated_duration,
                'is_public': updated_course.is_public,
                'updated_at': updated_course.updated_at,
            }
            
            return True, result, _('تم تحديث المسار بنجاح')
            
        except IntegrityError as e:
            if 'unique_course_title' in str(e):
                return False, {'title': _('يوجد بالفعل مسار نشط بنفس العنوان')}, _('تعذر تحديث المسار')
            return False, None, str(e)
        except Exception as e:
            return False, None, str(e)
    
    @staticmethod
    def delete_course(course_id: int, user) -> Tuple[bool, Optional[Dict[str, Any]], Optional[str]]:
        """حذف مسار (Soft Delete)"""
        try:
            # التحقق من صلاحية المستخدم
            if not user.is_admin:
                return False, None, _('يجب أن تكون مشرفاً لحذف المسار')
            
            # الحصول على المسار
            course = CourseRepository.get_by_id(course_id)
            if not course:
                return False, None, _('المسار غير موجود')
            
            # حذف المسار
            deleted_course = CourseRepository.soft_delete_course(course)
            
            # إعداد النتيجة
            result = {
                'id': deleted_course.id,
                'title': deleted_course.title,
                'instructor': deleted_course.instructor.email,
                'deleted_by': user.email,
                'deleted_at': deleted_course.updated_at,
            }
            
            return True, result, _('تم حذف المسار بنجاح')
            
        except Exception as e:
            return False, None, str(e)
    
    @staticmethod
    def get_course_details(course_id: int, user) -> Tuple[bool, Optional[Dict[str, Any]], Optional[str]]:
        """الحصول على تفاصيل المسار"""
        try:
            # الحصول على المسار
            course = CourseRepository.get_by_id(course_id)
            if not course:
                return False, None, _('المسار غير موجود')
            
            # التحقق من صلاحية الوصول
            if not user.is_admin and not course.is_public:
                return False, None, _('ليس لديك صلاحية للوصول لهذا المسار')
            
            # تحديث عدد المشاريع
            actual_projects = CourseRepository.update_projects_count(course)
            
            # إعداد البيانات
            result = {
                'id': course.id,
                'title': course.title,
                'description': course.description,
                'level': course.level,
                'level_display': course.get_level_display(),
                'category': course.category,
                'category_display': course.get_category_display(),
                'estimated_duration': course.estimated_duration,
                'projects_count': course.projects_count,
                'actual_projects_count': actual_projects,
                'is_public': course.is_public,
                'is_active': course.is_active,
                'instructor': {
                    'id': course.instructor.id,
                    'email': course.instructor.email,
                    'name': f"{course.instructor.first_name} {course.instructor.last_name}".strip(),
                },
                'enrolled_students_count': course.enrolled_learners.count(),
                'created_at': course.created_at,
                'updated_at': course.updated_at,
            }
            
            return True, result, _('تم جلب بيانات المسار بنجاح')
            
        except Exception as e:
            return False, None, str(e)
    
    @staticmethod
    def get_courses_list(user) -> Tuple[bool, Optional[list], Optional[str]]:
        """الحصول على قائمة المسارات"""
        try:
            # الحصول على المسارات المناسبة للمستخدم
            courses = CourseQueries.get_active_courses_for_user(user)
            
            if not courses.exists():
                return True, [], _('لا توجد مسارات متاحة')
            
            # إعداد البيانات
            result = []
            for course in courses:
                # تحديث عدد المشاريع لكل مسار
                actual_projects = CourseRepository.update_projects_count(course)
                
                result.append({
                    'id': course.id,
                    'title': course.title,
                    'description': course.description,
                    'level': course.level,
                    'level_display': course.get_level_display(),
                    'category': course.category,
                    'category_display': course.get_category_display(),
                    'estimated_duration': course.estimated_duration,
                    'projects_count': course.projects_count,
                    'actual_projects_count': actual_projects,
                    'is_public': course.is_public,
                    'is_active': course.is_active,
                    'instructor_name': f"{course.instructor.first_name} {course.instructor.last_name}".strip() or course.instructor.email,
                    'enrolled_students_count': course.enrolled_learners.count(),
                    'created_at': course.created_at,
                    'updated_at': course.updated_at,
                })
            
            return True, result, _('تم جلب المسارات بنجاح')
            
        except Exception as e:
            return False, None, str(e)