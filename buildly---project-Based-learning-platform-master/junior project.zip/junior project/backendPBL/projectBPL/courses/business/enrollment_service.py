# courses/business/enrollment_service.py
from typing import Tuple, Optional, Dict, Any, List
from django.utils.translation import gettext_lazy as _
from courses.data.repositories import CourseRepository

class EnrollmentService:
    """خدمة منطق الأعمال للانضمام للمسارات - فقط منطق الأعمال"""
    
    @staticmethod
    def enroll_learner_in_course(course_id: int, user) -> Tuple[bool, Optional[Dict[str, Any]], Optional[str]]:
        """انضمام متعلم لمسار"""
        try:
            # التحقق من صلاحية المستخدم
            if not hasattr(user, 'is_learner') or not user.is_learner:
                return False, None, _('فقط المتعلمين يمكنهم الانضمام للمسار')
            
            # الحصول على المسار
            course = CourseRepository.get_by_id(course_id)
            if not course:
                return False, None, _('المسار غير موجود')
            
            # التحقق من نشاط المسار
            if not course.is_active:
                return False, None, _('هذا المسار غير متاح حالياً')
            
            # التحقق من الانضمام المسبق
            if CourseRepository.is_learner_enrolled(course, user):
                return False, None, _('أنت منضم بالفعل لهذا المسار')
            
            # إضافة المتعلم للمسار
            if CourseRepository.add_learner_to_course(course, user):
                # إعداد النتيجة
                result = {
                    'course': {
                        'id': course.id,
                        'title': course.title,
                        'enrolled_students_count': course.enrolled_learners.count(),
                    },
                    'student': {
                        'id': user.id,
                        'email': user.email,
                        'name': f"{user.first_name} {user.last_name}".strip(),
                    }
                }
                
                return True, result, _('تم الانضمام للمسار بنجاح')
            else:
                return False, None, _('فشل الانضمام للمسار')
            
        except Exception as e:
            return False, None, str(e)
    
    @staticmethod
    def check_enrollment_status(course_id: int, user) -> Tuple[bool, Optional[Dict[str, Any]], Optional[str]]:
        """التحقق من حالة انضمام المستخدم للمسار"""
        try:
            # الحصول على المسار
            course = CourseRepository.get_by_id(course_id)
            if not course:
                return False, None, _('المسار غير موجود')
            
            # التحقق من انضمام المستخدم
            is_enrolled = CourseRepository.is_learner_enrolled(course, user)
            
            result = {
                'is_enrolled': is_enrolled,
                'course': {
                    'id': course.id,
                    'title': course.title,
                    'is_public': course.is_public,
                    'enrolled_learners_count': course.enrolled_learners.count(),
                }
            }
            
            return True, result, _('تم التحقق من حالة الانضمام')
            
        except Exception as e:
            return False, None, str(e)
    
    @staticmethod
    def get_user_enrolled_courses(user) -> Tuple[bool, Optional[List[Dict[str, Any]]], Optional[str]]:
        """الحصول على المسارات التي انضم إليها المستخدم"""
        try:
            # التحقق من صلاحية المستخدم
            if not hasattr(user, 'is_learner') or not user.is_learner:
                return False, None, _('فقط المتعلمين يمكنهم الانضمام للمسار')
            
            from courses.data.queries import CourseQueries
            
            # الحصول على المسارات
            courses = CourseQueries.get_user_enrolled_courses(user)
            
            if not courses.exists():
                return True, [], _('لم تنضم لأي مسار بعد')
            
            # إعداد البيانات
            result = []
            for course in courses:
                # تحديث عدد المشاريع لكل مسار
                actual_projects = CourseRepository.update_projects_count(course)
                
                result.append({
                    'id': course.id,
                    'title': course.title,
                    'description': course.description,
                    'level': course.level,
                    'level_display': course.get_level_display(),
                    'category': course.category,
                    'category_display': course.get_category_display(),
                    'estimated_duration': course.estimated_duration,
                    'projects_count': course.projects_count,
                    'actual_projects_count': actual_projects,
                    'is_public': course.is_public,
                    'instructor_name': f"{course.instructor.first_name} {course.instructor.last_name}".strip() or course.instructor.email,
                    'enrolled_students_count': course.enrolled_learners.count(),
                    'created_at': course.created_at,
                    'updated_at': course.updated_at,
                })
            
            return True, result, _('تم جلب المسارات الخاصة بك بنجاح')
            
        except Exception as e:
            return False, None, str(e)