# courses/models/__init__.py
from .course import Course