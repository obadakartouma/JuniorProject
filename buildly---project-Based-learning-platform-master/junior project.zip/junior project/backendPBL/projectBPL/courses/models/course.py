# courses/models/course.py
from django.db import models
from django.utils.translation import gettext_lazy as _
from account.models import CustomUser

class Course(models.Model):
    """نموذج المسار التعليمي - فقط بنية البيانات"""
    LEVEL_CHOICES = (
        ('beginner', 'مبتدئ'),
        ('intermediate', 'متوسط'),
        ('advanced', 'متقدم'),
        ('expert', 'خبير'),
    )
    CATEGORY_CHOICES = (
        ('web', 'تطوير الويب'),
        ('mobile', 'تطوير الموبايل'),
        ('data', 'علوم البيانات'),
        ('ai', 'الذكاء الاصطناعي'),
        ('design', 'التصميم'),
        ('business', 'أعمال'),
        ('language', 'لغات'),
        ('other', 'أخرى'),
    )
    
    title = models.CharField(
        max_length=200,
        verbose_name='عنوان المسار',
        help_text='أدخل عنواناً واضحاً ومعبراً للمسار'
    )
    description = models.TextField(
        verbose_name='وصف المسار',
        help_text='أدخل وصفاً مفصلاً للمسار التعليمي'
    )
    level = models.CharField(
        max_length=20,
        choices=LEVEL_CHOICES,
        default='beginner',
        verbose_name='المستوى'
    )
    category = models.CharField(
        max_length=20,
        choices=CATEGORY_CHOICES,
        default='other',
        verbose_name='الفئة'
    )
    estimated_duration = models.IntegerField(
        verbose_name='المدة المقدرة (بالساعات)',
        help_text='أدخل المدة المقدرة لإتمام المسار بالساعات'
    )
    projects_count = models.IntegerField(
        default=0,
        verbose_name='عدد المشاريع',
        help_text='عدد المشاريع العملية في هذا المسار',
        editable=False
    )
    is_public = models.BooleanField(
        default=False,
        verbose_name='عام للجميع',
        help_text='هل هذا المسار متاح للجميع؟'
    )
    instructor = models.ForeignKey(
        CustomUser,
        on_delete=models.CASCADE,
        related_name='courses_created',
        verbose_name='المشرف'
    )
    enrolled_learners = models.ManyToManyField(
        CustomUser,
        related_name='enrolled_courses_as_learner',
        verbose_name='المتعلمين المنضمين',
        blank=True,
        help_text='المتعلمين المنضمين فقط - لا يتم إضافة مشرفين',
        limit_choices_to={'user_type': 'learner'} 
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name='تاريخ الإنشاء'
    )
    updated_at = models.DateTimeField(
        auto_now=True,
        verbose_name='تاريخ التحديث'
    )
    is_active = models.BooleanField(
        default=True,
        verbose_name='نشط',
        help_text='هل هذا المسار نشط أم معطل؟'
    )
    
    class Meta:
        verbose_name = _('مسار تعليمي')
        verbose_name_plural = _('المسارات التعليمية')
        ordering = ['-created_at']
        constraints = [
            models.UniqueConstraint(
                fields=['title'],
                name='unique_course_title',
                condition=models.Q(is_active=True),
                violation_error_message='يوجد بالفعل مسار نشط بهذا العنوان في النظام'
            )
        ]
    
    def __str__(self):
        return f"{self.title} - {self.get_level_display()}"
    
    def save(self, *args, **kwargs):
        """حفظ المسار مع التحقق الأساسي"""
        if not self.instructor.is_admin:
            raise ValueError('يجب أن يكون منشئ المسار مشرفاً')
        
        super().save(*args, **kwargs)