# courses/api/serializers.py
from rest_framework import serializers
from django.utils.translation import gettext_lazy as _
from courses.models.course import Course

class CourseCreateSerializer(serializers.ModelSerializer):
    """Serializer لإنشاء مسار - فقط تحقق من صحة البيانات الأساسية"""
    
    class Meta:
        model = Course
        fields = [
            'title', 'description', 'level', 'category',
            'estimated_duration', 'is_public'
        ]
        extra_kwargs = {
            'title': {
                'required': True,
                'allow_blank': False,
                'error_messages': {
                    'required': _('عنوان المسار مطلوب'),
                    'blank': _('عنوان المسار لا يمكن أن يكون فارغاً')
                }
            },
            'description': {
                'required': True,
                'allow_blank': False,
                'error_messages': {
                    'required': _('وصف المسار مطلوب'),
                    'blank': _('وصف المسار لا يمكن أن يكون فارغاً')
                }
            },
            'estimated_duration': {
                'required': True,
                'error_messages': {
                    'required': _('المدة المقدرة مطلوبة'),
                    'invalid': _('المدة يجب أن تكون رقم صحيح')
                }
            },
            'is_public': {
                'required': False,
                'default': False
            }
        }
    
    def validate_title(self, value):
        """تحقق أساسي من العنوان"""
        value = value.strip()
        if not value:
            raise serializers.ValidationError(_('عنوان المسار مطلوب'))
        if len(value) < 3:
            raise serializers.ValidationError(_('العنوان يجب أن يكون 3 أحرف على الأقل'))
        return value
    
    def validate_description(self, value):
        """تحقق أساسي من الوصف"""
        value = value.strip()
        if len(value) < 20:
            raise serializers.ValidationError(_('الوصف يجب أن يكون على الأقل 20 حرفاً'))
        return value
    
    def validate_estimated_duration(self, value):
        """تحقق أساسي من المدة"""
        if value <= 0:
            raise serializers.ValidationError(_('المدة يجب أن تكون أكبر من صفر'))
        if value > 1000:
            raise serializers.ValidationError(_('المدة لا يمكن أن تتجاوز 1000 ساعة'))
        return value

class CourseListSerializer(serializers.ModelSerializer):
    """Serializer لعرض قائمة المسارات"""
    
    instructor_name = serializers.SerializerMethodField()
    level_display = serializers.CharField(source='get_level_display')
    category_display = serializers.CharField(source='get_category_display')
    enrolled_students_count = serializers.SerializerMethodField()
    
    class Meta:
        model = Course
        fields = [
            'id', 'title', 'description', 'level', 'level_display',
            'category', 'category_display', 'estimated_duration',
            'projects_count', 'is_public', 'is_active', 'created_at',  
            'updated_at', 'instructor_name', 'enrolled_students_count'
        ]
        read_only_fields = ['projects_count']
    
    def get_instructor_name(self, obj):
        """الحصول على اسم المشرف"""
        first_name = obj.instructor.first_name or ""
        last_name = obj.instructor.last_name or ""
        if first_name or last_name:
            return f"{first_name} {last_name}".strip()
        return obj.instructor.email or "مشرف النظام"
    
    def get_enrolled_students_count(self, obj):
        """الحصول على عدد المتعلمين"""
        return obj.enrolled_learners.count()

class CourseDetailSerializer(serializers.ModelSerializer):
    """Serializer لعرض تفاصيل المسار"""
    
    course_projects = serializers.SerializerMethodField()
    instructor_name = serializers.SerializerMethodField()
    level_display = serializers.CharField(source='get_level_display')
    category_display = serializers.CharField(source='get_category_display')
    enrolled_students_count = serializers.SerializerMethodField()
    enrolled_students_emails = serializers.SerializerMethodField()
    
    class Meta:
        model = Course
        fields = [
            'id', 'title', 'description', 'level', 'level_display',
            'category', 'category_display', 'estimated_duration',
            'projects_count', 'is_public', 'created_at', 'instructor_name',
            'enrolled_students_count', 'enrolled_students_emails', 'course_projects'
        ]
        read_only_fields = ['projects_count']
    
    def get_instructor_name(self, obj):
        """الحصول على اسم المشرف"""
        first_name = obj.instructor.first_name or ""
        last_name = obj.instructor.last_name or ""
        if first_name or last_name:
            return f"{first_name} {last_name}".strip()
        return obj.instructor.email or "مشرف النظام"
    
    def get_enrolled_students_count(self, obj):
        """الحصول على عدد المتعلمين"""
        return obj.enrolled_learners.count()
    
    def get_enrolled_students_emails(self, obj):
        """الحصول على بريد المتعلمين"""
        return list(obj.enrolled_learners.values_list('email', flat=True))
    
    def get_course_projects(self, obj):
        """الحصول على مشاريع المسار"""
        request = self.context.get('request')
        try:
            from projects.serializers import ProjectListSerializer
            projects = obj.projects.filter(is_active=True).order_by('order')
            serializer = ProjectListSerializer(
                projects, 
                many=True,
                context={'request': request}
            )
            return serializer.data
        except:
            return []

class CourseUpdateSerializer(serializers.ModelSerializer):
    """Serializer لتحديث المسار"""
    
    class Meta:
        model = Course
        fields = [
            'title', 'description', 'level',
            'category', 'estimated_duration', 'is_public'
        ]
        extra_kwargs = {
            'title': {
                'required': True,
                'allow_blank': False,
                'error_messages': {
                    'required': _('عنوان المسار مطلوب ولا يمكن أن يكون فارغاً'),
                    'blank': _('عنوان المسار لا يمكن أن يكون فارغاً')
                }
            },
            'description': {
                'required': True,
                'allow_blank': False,
                'error_messages': {
                    'required': _('وصف المسار مطلوب ولا يمكن أن يكون فارغاً'),
                    'blank': _('وصف المسار لا يمكن أن يكون فارغاً')
                }
            },
            'estimated_duration': {
                'required': True,
                'error_messages': {
                    'required': _('المدة المقدرة مطلوبة'),
                    'invalid': _('المدة يجب أن تكون رقم صحيح')
                }
            }
        }