# courses/api/views.py
from rest_framework import permissions, status
from rest_framework.response import Response
from rest_framework.views import APIView
from django.utils.translation import gettext_lazy as _
from django.db import transaction
from courses.api.serializers import (
    CourseCreateSerializer, CourseUpdateSerializer
)
from courses.business.course_service import CourseService
from courses.business.enrollment_service import EnrollmentService

class IsAdminUser(permissions.BasePermission):
    """صلاحية المشرفين فقط"""
    def has_permission(self, request, view):
        return bool(request.user and request.user.is_authenticated and request.user.is_admin)

class IsLearnerUser(permissions.BasePermission):
    """صلاحية المتعلمين فقط"""
    def has_permission(self, request, view):
        return bool(
            request.user and 
            request.user.is_authenticated and 
            getattr(request.user, 'is_learner', False)
        )

class CreateCourseView(APIView):
    """إنشاء مسار جديد"""
    permission_classes = [permissions.IsAuthenticated, IsAdminUser]
    
    @transaction.atomic
    def post(self, request):
        serializer = CourseCreateSerializer(data=request.data, context={'request': request})
        
        if not serializer.is_valid():
            return Response({
                'success': False,
                'message': _('بيانات غير صالحة'),
                'errors': serializer.errors,
            }, status=status.HTTP_400_BAD_REQUEST)
        
        # استخدام خدمة الأعمال لإنشاء المسار
        success, result, message = CourseService.create_course(
            request.user, 
            serializer.validated_data
        )
        
        if success:
            return Response({
                'success': True,
                'message': message,
                'course': result
            }, status=status.HTTP_201_CREATED)
        else:
            return Response({
                'success': False,
                'message': message,
                'errors': result if result else None,
            }, status=status.HTTP_400_BAD_REQUEST)

class UpdateCourseView(APIView):
    """تحديث مسار موجود"""
    permission_classes = [permissions.IsAuthenticated, IsAdminUser]
    
    def get(self, request, id):
        """الحصول على بيانات المسار للتحديث"""
        success, result, message = CourseService.get_course_details(id, request.user)
        
        if success:
            return Response({
                'success': True,
                'course': result
            })
        else:
            return Response({
                'success': False,
                'message': message
            }, status=status.HTTP_404_NOT_FOUND)

    @transaction.atomic
    def put(self, request, id):
        """تحديث المسار"""
        serializer = CourseUpdateSerializer(data=request.data)
        
        if not serializer.is_valid():
            return Response({
                'success': False,
                'message': _('بيانات غير صالحة'),
                'errors': serializer.errors,
            }, status=status.HTTP_400_BAD_REQUEST)
        
        # استخدام خدمة الأعمال لتحديث المسار
        success, result, message = CourseService.update_course(
            id, 
            request.user, 
            serializer.validated_data
        )
        
        if success:
            return Response({
                'success': True,
                'message': message,
                'course': result
            }, status=status.HTTP_200_OK)
        else:
            return Response({
                'success': False,
                'message': message,
                'errors': result if result else None,
            }, status=status.HTTP_400_BAD_REQUEST)

class RetrieveCourseView(APIView):
    """استرجاع مسار (للمشرفين)"""
    permission_classes = [permissions.IsAuthenticated, IsAdminUser]
    
    def get(self, request, id):
        success, result, message = CourseService.get_course_details(id, request.user)
        
        if success:
            return Response({
                'success': True,
                'message': message,
                'course': result
            })
        else:
            return Response({
                'success': False,
                'message': message
            }, status=status.HTTP_404_NOT_FOUND)

class DeleteCourseView(APIView):
    """حذف مسار"""
    permission_classes = [permissions.IsAuthenticated, IsAdminUser]
    
    @transaction.atomic
    def delete(self, request, id):
        success, result, message = CourseService.delete_course(id, request.user)
        
        if success:
            return Response({
                'success': True,
                'message': message,
                'deleted_course': result
            })
        else:
            return Response({
                'success': False,
                'message': message
            }, status=status.HTTP_400_BAD_REQUEST)

class ConfirmDeleteCourseView(APIView):
    """تأكيد حذف مسار"""
    permission_classes = [permissions.IsAuthenticated, IsAdminUser]
    
    def get(self, request, id):
        success, result, message = CourseService.get_course_details(id, request.user)
        
        if success:
            # إضافة بيانات التأكيد
            result['confirmation_message'] = _('هل أنت متأكد من حذف هذا المسار؟')
            result['warning_message'] = _('تحذير: هذه العملية لا يمكن التراجع عنها')
            result['note'] = _('أنت على وشك حذف مسار أنشأه: ') + result['instructor']['email']
            result['current_user'] = request.user.email
            
            return Response({
                'success': True,
                'message': _('بيانات المسار للتأكيد قبل الحذف'),
                'course': result,
                'confirmation_required': True
            })
        else:
            return Response({
                'success': False,
                'message': message
            }, status=status.HTTP_404_NOT_FOUND)

class ListCoursesView(APIView):
    """قائمة المسارات"""
    permission_classes = [permissions.IsAuthenticated]
    
    def get(self, request):
        success, result, message = CourseService.get_courses_list(request.user)
        
        return Response({
            'success': True,
            'message': message,
            'count': len(result) if result else 0,
            'courses': result if result else []
        })

class CourseDetailView(APIView):
    """تفاصيل المسار (للجميع)"""
    permission_classes = [permissions.IsAuthenticated]
    
    def get(self, request, id):
        success, result, message = CourseService.get_course_details(id, request.user)
        
        if success:
            # إضافة معلومات إضافية
            from courses.models.course import Course
            additional_info = {
                'available_levels': dict(Course.LEVEL_CHOICES),
                'available_categories': dict(Course.CATEGORY_CHOICES),
                'total_enrolled': result['enrolled_students_count'],
                'has_projects': result['actual_projects_count'] > 0,
                'actual_projects_count': result['actual_projects_count'],
                'can_manage_projects': request.user.is_admin
            }
            
            return Response({
                'success': True,
                'message': message,
                'course': result,
                'additional_info': additional_info
            })
        else:
            return Response({
                'success': False,
                'message': message
            }, status=status.HTTP_400_BAD_REQUEST)

class JoinCourseView(APIView):
    """الانضمام لمسار"""
    permission_classes = [permissions.IsAuthenticated, IsLearnerUser]
    
    def post(self, request, id):
        success, result, message = EnrollmentService.enroll_learner_in_course(id, request.user)
        
        if success:
            return Response({
                'success': True,
                'message': message,
                'enrollment': result
            }, status=status.HTTP_201_CREATED)
        else:
            status_code = status.HTTP_400_BAD_REQUEST
            if 'غير موجود' in message:
                status_code = status.HTTP_404_NOT_FOUND
            elif 'صلاحية' in message or 'فقط المتعلمين' in message:
                status_code = status.HTTP_403_FORBIDDEN
            
            return Response({
                'success': False,
                'message': message
            }, status=status_code)

class UserEnrolledCoursesView(APIView):
    """مسارات المستخدم"""
    permission_classes = [permissions.IsAuthenticated, IsLearnerUser]
    
    def get(self, request):
        success, result, message = EnrollmentService.get_user_enrolled_courses(request.user)
        
        return Response({
            'success': True,
            'message': message,
            'count': len(result) if result else 0,
            'courses': result if result else []
        })

class CheckEnrollmentView(APIView):
    """التحقق من الانضمام"""
    permission_classes = [permissions.IsAuthenticated, IsLearnerUser]
    
    def get(self, request, id):
        success, result, message = EnrollmentService.check_enrollment_status(id, request.user)
        
        if success:
            return Response({
                'success': True,
                'message': message,
                **result
            })
        else:
            return Response({
                'success': False,
                'message': message
            }, status=status.HTTP_404_NOT_FOUND)