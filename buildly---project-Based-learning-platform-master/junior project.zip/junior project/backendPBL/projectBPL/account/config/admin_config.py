# accounts/config/admin_config.py
from django.utils.translation import gettext_lazy as _

class AdminConfig:
    """إعدادات حساب المشرف الثابت - بيانات عامة"""
    ADMIN_EMAIL = "admin@smartlearning.com"
    ADMIN_PASSWORD = "SmartAdmin@2024"
    ADMIN_DISPLAY_NAME = "إدارة النظام"
    
    @classmethod
    def get_admin_credentials(cls):
        """الحصول على بيانات اعتماد المشرف"""
        return {
            'email': cls.ADMIN_EMAIL,
            'password': cls.ADMIN_PASSWORD,
            'display_name': cls.ADMIN_DISPLAY_NAME,
            'first_name': 'إدارة',
            'last_name': 'النظام'
        }
    
    @classmethod
    def is_admin_email(cls, email):
        """التحقق إذا كان البريد هو بريد المشرف"""
        return email == cls.ADMIN_EMAIL