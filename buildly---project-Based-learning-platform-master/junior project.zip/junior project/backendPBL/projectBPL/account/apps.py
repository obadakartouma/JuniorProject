# account/apps.py
from django.apps import AppConfig
from django.utils.translation import gettext_lazy as _

class AccountConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'account'  # هذا صحيح - اسم التطبيق هو account
    verbose_name = _('إدارة الحسابات')
    
    def ready(self):
        pass  # يمكنك إضافة signals هنا لاحقاً