# accounts/models/user.py
from django.db import models
from django.contrib.auth.models import AbstractUser, BaseUserManager
from django.utils.translation import gettext_lazy as _
from django.db.models.signals import post_migrate
from django.dispatch import receiver

class CustomUserManager(BaseUserManager):
    """مدير بسيط فقط للعمليات الأساسية"""
    
    def create_user(self, email, password=None, **extra_fields):
        """إنشاء مستخدم عادي فقط"""
        # منع إنشاء أي مستخدم بنوع admin
        if extra_fields.get('user_type') == 'admin':
            raise ValueError(_('إنشاء حساب مشرف غير مسموح عبر هذه الطريقة'))
            
        email = self.normalize_email(email)
        user = self.model(email=email, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user
    
    def create_superuser(self, email, password=None, **extra_fields):
        """تعطيل إنشاء superuser - لا نستخدمه"""
        raise ValueError(_('إنشاء حسابات مشرفين غير مسموح في هذا النظام'))

class CustomUser(AbstractUser):
    """نموذج مستخدم مخصص مع حقول إضافية"""
    USER_TYPE_CHOICES = (
        ('learner', 'متعلم'),
        ('admin', 'مشرف'),
    )
    
    username = None
    email = models.EmailField(_('البريد الإلكتروني'), unique=True)
    user_type = models.CharField(
        max_length=10, 
        choices=USER_TYPE_CHOICES, 
        default='learner',
        verbose_name='نوع المستخدم'
    )
    enrolled_courses_titles = models.JSONField(
        default=list,
        blank=True,
        null=True
    )
    
    objects = CustomUserManager()
    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = []
    
    def __str__(self):
        return self.email
    
    def get_user_type_display(self):
        return dict(self.USER_TYPE_CHOICES).get(self.user_type, self.user_type)
    
    @property
    def is_learner(self):
        return self.user_type == 'learner'
    
    @property
    def is_admin(self):
        return self.user_type == 'admin' or self.is_superuser
    
    def save(self, *args, **kwargs):
        if self.user_type == 'admin':
            self.enrolled_courses_titles = None
        super().save(*args, **kwargs)
    
    class Meta:
        verbose_name = _('مستخدم')
        verbose_name_plural = _('المستخدمين')

@receiver(post_migrate)
def create_admin_user(sender, **kwargs):
    """إنشاء حساب المشرف الثابت عند تهيئة قاعدة البيانات"""
    from django.contrib.auth import get_user_model
    
    User = get_user_model()
    
    # استيراد AdminConfig بشكل آمن
    try:
        from account.config.admin_config import AdminConfig
        credentials = AdminConfig.get_admin_credentials()
        admin_email = credentials['email']
        admin_password = credentials['password']
        first_name = credentials.get('first_name', 'إدارة')
        last_name = credentials.get('last_name', 'النظام')
    except ImportError:
        # في حال لم يتم العثور على الملف، استخدم قيم افتراضية
        admin_email = "admin@smartlearning.com"
        admin_password = "SmartAdmin@2024"
        first_name = "إدارة"
        last_name = "النظام"
    
    # تحقق إذا كان الحساب موجوداً بالفعل
    if not User.objects.filter(email=admin_email).exists():
        try:
            # إنشاء المستخدم
            user = User(
                email=admin_email,
                user_type='admin',
                is_staff=True,
                is_superuser=True,
                is_active=True,
                first_name=first_name,
                last_name=last_name
            )
            user.set_password(admin_password)
            user.save(using='default')
            print(f"✅ تم إنشاء حساب المشرف الثابت: {admin_email}")
            print(f"👤 الاسم: {first_name} {last_name}")
        except Exception as e:
            print(f"❌ فشل إنشاء حساب المشرف: {e}")
    else:
        # تحديث كلمة المرور والمعلومات إذا كان الحساب موجوداً
        try:
            user = User.objects.get(email=admin_email)
            user.set_password(admin_password)
            user.first_name = first_name
            user.last_name = last_name
            user.save()
            print(f"✅ تم تحديث حساب المشرف الثابت: {admin_email}")
        except Exception as e:
            print(f"❌ فشل تحديث حساب المشرف: {e}")