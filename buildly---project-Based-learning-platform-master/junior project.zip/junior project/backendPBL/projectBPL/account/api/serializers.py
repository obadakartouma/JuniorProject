# accounts/api/serializers.py
from rest_framework import serializers
from ..models.user import CustomUser
from account.config.admin_config import AdminConfig  # إضافة هذا الاستيراد

class RegisterLearnerSerializer(serializers.ModelSerializer):
    """فقط تحقق من البيانات الأساسية للمتعلمين"""
    password = serializers.CharField(write_only=True, required=True)
    password2 = serializers.CharField(write_only=True, required=True)
    
    class Meta:
        model = CustomUser
        fields = ('email', 'password', 'password2')
    
    def validate_email(self, value):
        """التحقق من البريد الإلكتروني"""
        # منع استخدام بريد المشرف
        if AdminConfig.is_admin_email(value):
            raise serializers.ValidationError("لا يمكن استخدام هذا البريد الإلكتروني")
        return value
    
    def validate(self, attrs):
        """التحقق الأساسي فقط"""
        if attrs['password'] != attrs['password2']:
            raise serializers.ValidationError({
                "password": "كلمات المرور غير متطابقة"
            })
        return attrs

class LoginSerializer(serializers.Serializer):
    """فقط تعريف الحقول"""
    email = serializers.EmailField(required=True)
    password = serializers.CharField(write_only=True, required=True)

class ProfileSerializer(serializers.ModelSerializer):
    """فقط تعريف كيف تُعرض البيانات"""
    enrolled_courses_count = serializers.SerializerMethodField()
    enrolled_courses_titles = serializers.SerializerMethodField()
    
    class Meta:
        model = CustomUser
        fields = ('id', 'email', 'user_type', 'date_joined', 
                 'last_login', 'enrolled_courses_count', 'enrolled_courses_titles')
        read_only_fields = fields
    
    def get_enrolled_courses_count(self, obj):
        return getattr(obj, 'enrolled_courses_count', None)
    
    def get_enrolled_courses_titles(self, obj):
        return getattr(obj, 'enrolled_courses_titles', None)