# account/api/views.py
from rest_framework import generics, permissions, status
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework_simplejwt.token_blacklist.models import BlacklistedToken
from django.contrib.auth import logout
from django.utils.translation import gettext_lazy as _
from ..business.auth_service import AuthService
from ..business.user_service import UserService
from ..business.dashboard_service import DashboardService
from .serializers import (
    RegisterLearnerSerializer, 
    LoginSerializer, 
    ProfileSerializer
)

class RegisterLearnerView(generics.CreateAPIView):
    """تسجيل متعلمين فقط - نظيف تماماً"""
    serializer_class = RegisterLearnerSerializer
    permission_classes = [permissions.AllowAny]
    
    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        
        try:
            result = AuthService.register_learner(
                email=serializer.validated_data['email'],
                password=serializer.validated_data['password'],
                password2=request.data.get('password2', '')
            )
            
            return Response({
                'message': _('تم إنشاء حساب المتعلم بنجاح'),
                'user': result['user_data'],
                'tokens': result['tokens']
            }, status=status.HTTP_201_CREATED)
            
        except ValueError as e:
            return Response({
                'error': str(e)
            }, status=status.HTTP_400_BAD_REQUEST)

class LoginView(APIView):
    """تسجيل الدخول للمتعلمين والمشرف - نظيف تماماً"""
    permission_classes = [permissions.AllowAny]
    
    def post(self, request):
        serializer = LoginSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        
        try:
            result = AuthService.login(
                email=serializer.validated_data['email'],
                password=serializer.validated_data['password']
            )
            
            return Response({
                'message': _('تم تسجيل الدخول بنجاح'),
                'user': result['user_data'],
                'tokens': result['tokens']
            })
            
        except ValueError as e:
            return Response({
                'error': str(e)
            }, status=status.HTTP_400_BAD_REQUEST)

class LogoutView(APIView):
    """نظيف تماماً - فقط توجيه"""
    permission_classes = [permissions.IsAuthenticated]
    
    def post(self, request):
        try:
            refresh_token = request.data.get("refresh_token")
            
            if not refresh_token:
                return Response({
                    'error': _('refresh_token مطلوب')
                }, status=status.HTTP_400_BAD_REQUEST)
            
            token = RefreshToken(refresh_token)
            token.blacklist()
            
            logout(request)
            
            return Response({
                'message': _('تم تسجيل الخروج بنجاح')
            }, status=status.HTTP_205_RESET_CONTENT)
            
        except Exception as e:
            return Response({
                'error': _('حدث خطأ أثناء تسجيل الخروج'),
                'details': str(e)
            }, status=status.HTTP_400_BAD_REQUEST)

class ProfileView(generics.RetrieveUpdateAPIView):
    """نظيف تماماً"""
    serializer_class = ProfileSerializer
    permission_classes = [permissions.IsAuthenticated]
    
    def get_object(self):
        return self.request.user
    
    def retrieve(self, request, *args, **kwargs):
        try:
            result = UserService.get_user_profile(
                user_id=request.user.id,
                request_user=request.user
            )
            
            return Response({
                'message': _('تم جلب بيانات الملف الشخصي'),
                'user': result['profile_data']
            })
            
        except ValueError as e:
            return Response({
                'error': str(e)
            }, status=status.HTTP_400_BAD_REQUEST)
    
    def update(self, request, *args, **kwargs):
        try:
            result = UserService.update_user_profile(
                user_id=request.user.id,
                update_data=request.data,
                request_user=request.user
            )
            
            return Response({
                'message': _('تم تحديث الملف الشخصي بنجاح'),
                'user': result['profile_data']
            })
            
        except ValueError as e:
            return Response({
                'error': str(e)
            }, status=status.HTTP_400_BAD_REQUEST)

class LearnerDashboardView(APIView):
    """لوحة تحكم المتعلم - نظيفة تماماً"""
    permission_classes = [permissions.IsAuthenticated]
    
    def get(self, request):
        try:
            dashboard_data = DashboardService.get_learner_dashboard(request.user)
            
            profile_result = UserService.get_user_profile(
                user_id=request.user.id,
                request_user=request.user
            )
            
            return Response({
                'message': _('لوحة تحكم المتعلم'),
                'user_profile': profile_result['profile_data'],
                **dashboard_data
            })
            
        except ValueError as e:
            return Response({
                'error': str(e)
            }, status=status.HTTP_403_FORBIDDEN)

class LearnerProgressAPIView(APIView):
    """تقدم المتعلم - نظيفة تماماً"""
    permission_classes = [permissions.IsAuthenticated]
    
    def get(self, request):
        try:
            progress_data = DashboardService.get_learner_progress(request.user)
            
            return Response({
                'message': _('تتبع تقدم المتعلم'),
                'progress_data': progress_data,
            })
            
        except ValueError as e:
            return Response({
                'error': str(e)
            }, status=status.HTTP_403_FORBIDDEN)