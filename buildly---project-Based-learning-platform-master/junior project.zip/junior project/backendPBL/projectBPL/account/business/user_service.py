# accounts/business/services/user_service.py

# خدمات المستخدم - منطق العمل فقط

from django.utils.translation import gettext_lazy as _
from ..data.repositories import UserRepository
from .validation_service import ValidationService

class UserService:
    """خدمات المستخدم - منطق العمل فقط"""
    
    @staticmethod
    def get_user_profile(user_id, request_user=None):
        """جلب الملف الشخصي مع القواعد"""
        user = UserRepository.get_by_id(user_id)
        if not user:
            raise ValueError(_('المستخدم غير موجود'))
        
        # يمكن إضافة قواعد صلاحية هنا
        if request_user and request_user.id != user.id and not request_user.is_admin:
            raise ValueError(_('غير مصرح الوصول'))
        
        # تنسيق البيانات
        profile_data = UserService._format_profile_data(user)
        
        return {
            'user': user,
            'profile_data': profile_data
        }
    
    @staticmethod
    def update_user_profile(user_id, update_data, request_user):
        """تحديث الملف الشخصي مع القواعد"""
        user = UserRepository.get_by_id(user_id)
        if not user:
            raise ValueError(_('المستخدم غير موجود'))
        
        # التحقق من الصلاحية
        if request_user.id != user.id and not request_user.is_admin:
            raise ValueError(_('غير مصرح التعديل'))
        
        # التحقق من البريد إذا تم تغييره
        if 'email' in update_data:
            new_email = update_data['email']
            if new_email != user.email:
                # تحقق من الصيغة
                if not ValidationService.validate_email_format(new_email):
                    raise ValueError({'email': _('البريد الإلكتروني غير صالح')})
                
                # تحقق من الوجود
                if UserRepository.exists_by_email(new_email):
                    raise ValueError({'email': _('البريد الإلكتروني موجود مسبقاً')})
        
        # التحديث
        updated_user = UserRepository.update(user_id, **update_data)
        
        # تنسيق النتيجة
        profile_data = UserService._format_profile_data(updated_user)
        
        return {
            'user': updated_user,
            'profile_data': profile_data
        }
    
    @staticmethod
    def add_course_to_learner(user_id, course_title, request_user):
        """إضافة مسار مع كل القواعد"""
        user = UserRepository.get_by_id(user_id)
        if not user:
            raise ValueError(_('المستخدم غير موجود'))
        
        # القاعدة: فقط المتعلمين
        if not user.is_learner:
            raise ValueError(_('هذه الميزة للمتعلمين فقط'))
        
        # القاعدة: صلاحية التعديل
        if request_user.id != user.id and not request_user.is_admin:
            raise ValueError(_('غير مصرح الإضافة'))
        
        # القاعدة: المسار مطلوب
        if not course_title or not course_title.strip():
            raise ValueError(_('عنوان المسار مطلوب'))
        
        # التنفيذ
        success = UserRepository.add_course_to_learner(user_id, course_title)
        
        if not success:
            raise ValueError(_('المسار موجود بالفعل'))
        
        return {
            'success': True,
            'message': _('تمت الإضافة بنجاح'),
            'courses': UserRepository.get_learner_courses(user_id)
        }
    
    @staticmethod
    def _format_profile_data(user):
        """تنسيق بيانات الملف الشخصي - منطق عرض فقط"""
        data = {
            'id': user.id,
            'email': user.email,
            'user_type': user.get_user_type_display(),
            'date_joined': user.date_joined,
            'last_login': user.last_login,
        }
        
        if user.is_learner:
            courses = UserRepository.get_learner_courses(user.id)
            data.update({
                'enrolled_courses_count': len(courses),
                'enrolled_courses_titles': courses,
            })
        
        return data