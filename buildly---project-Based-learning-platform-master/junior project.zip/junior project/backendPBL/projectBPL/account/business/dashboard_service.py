# account/business/services/dashboard_service.py
from django.utils.translation import gettext_lazy as _
from django.utils import timezone
from datetime import timedelta
from courses.models.course import Course
from projects.models.project import Project

class DashboardService:
    """خدمات لوحة تحكم المتعلم - منطق العمل فقط"""
    
    @staticmethod
    def get_learner_dashboard(user):
        """الحصول على لوحة تحكم المتعلم مع كل القواعد"""
        # القاعدة 1: فقط المتعلمين
        if not user.is_learner:
            raise ValueError(_('هذه اللوحة مخصصة للمتعلمين فقط'))
        
        # 1. جلب المسارات الحقيقية من قاعدة البيانات
        courses = Course.objects.filter(
            enrolled_learners=user,
            is_active=True
        ).select_related('instructor').prefetch_related('projects')
        
        # 2. حساب الإحصائيات
        stats = DashboardService._calculate_stats(courses)
        
        # 3. إعداد المشاريع المنضم إليها
        enrolled_projects = DashboardService._prepare_enrolled_projects(courses)
        
        # 4. إعداد التقدم التعليمي
        learning_progress = DashboardService._prepare_learning_progress(courses)
        
        # 5. البيانات الإضافية
        notifications = DashboardService._get_notifications()
        recent_activity = DashboardService._get_recent_activity()
        suggested_projects = DashboardService._get_suggested_projects(courses)
        quick_actions = DashboardService._get_quick_actions()
        
        # 6. تنسيق النتيجة النهائية
        return {
            'dashboard_stats': stats,
            'enrolled_projects': enrolled_projects,
            'learning_progress': learning_progress,
            'notifications': notifications,
            'recent_activity': recent_activity,
            'suggested_projects': suggested_projects,
            'quick_actions': quick_actions,
        }
    
    @staticmethod
    def get_learner_progress(user):
        """الحصول على تقدم المتعلم مع كل القواعد"""
        # القاعدة 1: فقط المتعلمين
        if not user.is_learner:
            raise ValueError(_('غير مصرح'))
        
        # 1. جلب المسارات الحقيقية من قاعدة البيانات
        courses = Course.objects.filter(
            enrolled_learners=user,
            is_active=True
        ).select_related('instructor').prefetch_related('projects')
        
        # 2. تنسيق بيانات التقدم
        progress_data = {
            'overall': {
                'enrollment_date': user.date_joined.strftime('%Y-%m-%d'),
                'days_active': (timezone.now() - user.date_joined).days,
                'total_projects_enrolled': len(courses),
                'total_hours_estimated': len(courses) * 20,
            },
            'skill_development': DashboardService._calculate_skill_development(courses),
            'timeline': DashboardService._prepare_learning_timeline(courses, user),
            'achievements': DashboardService._get_achievements(courses, user),
        }
        
        return progress_data
    
    # ========== دوال مساعدة خاصة بالخدمة ==========
    
    @staticmethod
    def _calculate_stats(courses):
        """حساب الإحصائيات - منطق عمل"""
        # حساب عدد المشاريع الفعلية
        total_projects = sum(course.projects.filter(is_active=True).count() for course in courses)
        completed_projects = 0  # يمكن إضافة منطق لتتبع المشاريع المكتملة لاحقاً
        in_progress_projects = total_projects - completed_projects
        
        # حساب إجمالي الساعات المقدرة
        total_hours = sum(course.estimated_duration for course in courses)
        
        return {
            'total_enrolled_projects': len(courses),
            'completed_projects': completed_projects,
            'in_progress_projects': in_progress_projects,
            'total_hours_spent': total_hours,
            'current_streak_days': DashboardService._calculate_streak_days(),
            'skill_level': DashboardService._determine_skill_level(len(courses)),
            'completion_rate': DashboardService._calculate_completion_rate(len(courses)),
            'avg_project_score': 85,  # قاعدة: متوسط الدرجات
        }
    
    @staticmethod
    def _prepare_enrolled_projects(courses):
        """إعداد بيانات المسارات المنضم إليها - منطق عمل"""
        projects = []
        all_projects_list = []
        
        # جمع جميع المشاريع من جميع المسارات
        for course in courses:
            course_projects = course.projects.filter(is_active=True).order_by('order', 'created_at')
            for project in course_projects:
                all_projects_list.append({
                    'id': project.id,
                    'title': project.title,
                    'description': project.description[:100] + '...' if len(project.description) > 100 else project.description,
                    'course_id': course.id,
                    'course_title': course.title,
                    'category': course.get_category_display(),
                    'difficulty': project.get_level_display(),
                    'estimated_hours': project.estimated_time,
                    'progress_percentage': 0,  # يمكن إضافة منطق لتتبع التقدم لاحقاً
                    'language': project.get_language_display(),
                })
        
        # أخذ آخر 5 مشاريع
        projects = all_projects_list[:5]
        
        return {
            'count': len(projects),
            'projects': projects,
            'has_more': len(all_projects_list) > 5,
            'total_count': len(all_projects_list)
        }
    
    @staticmethod
    def _prepare_learning_progress(courses):
        """إعداد بيانات التقدم التعليمي - منطق عمل"""
        progress_data = []
        for course in courses[:6]:  # أول 6 مسارات
            projects_count = course.projects.filter(is_active=True).count()
            progress = {
                'project_name': course.title,
                'progress': 0,  # يمكن إضافة منطق لتتبع التقدم لاحقاً
                'skills_gained': DashboardService._get_skills_for_course(course.title),
                'time_spent': course.estimated_duration,
                'projects_count': projects_count,
                'last_update': course.updated_at.strftime('%Y-%m-%d') if course.updated_at else '',
            }
            progress_data.append(progress)
        
        # حساب التقدم الشهري
        monthly_progress = []
        for i in range(6):
            month_date = timezone.now() - timedelta(days=30*i)
            monthly_progress.append({
                'month': month_date.strftime('%b'),
                'completed_projects': 0,  # يمكن إضافة منطق لاحقاً
                'hours_spent': 0,  # يمكن إضافة منطق لاحقاً
            })
        
        # حساب التقدم الإجمالي
        total_projects = sum(c.projects.filter(is_active=True).count() for c in courses)
        overall_progress = min(100, (len(courses) * 10)) if courses else 0
        
        return {
            'overall_progress_percentage': overall_progress,
            'progress_by_project': progress_data,
            'monthly_progress': monthly_progress[::-1],
            'learning_trend': 'تصاعدي' if len(courses) > 0 else 'مستقر',
        }
    
    @staticmethod
    def _calculate_skill_development(courses):
        """حساب تطور المهارات - منطق عمل"""
        skills = {}
        for course in courses:
            category = course.get_category_display()
            if category not in skills:
                skills[category] = 0
            skills[category] += 20  # إضافة نقاط لكل مسار في نفس الفئة
        return skills
    
    @staticmethod
    def _prepare_learning_timeline(courses, user):
        """إعداد الخط الزمني - منطق عمل"""
        timeline = []
        sorted_courses = sorted(courses, key=lambda c: c.created_at, reverse=True)[:10]
        for i, course in enumerate(sorted_courses):
            timeline.append({
                'date': course.created_at.strftime('%Y-%m') if course.created_at else '',
                'event': f'الانضمام إلى مسار {course.title}',
                'milestone': 'بداية الرحلة' if i == 0 else 'خطوة جديدة',
            })
        return timeline
    
    @staticmethod
    def _get_achievements(courses, user):
        """الحصول على الإنجازات - منطق عمل"""
        enrolled_count = len(courses)
        achievements = []
        
        # قاعدة: إنجازات بناءً على عدد المسارات
        if enrolled_count >= 1:
            achievements.append({
                'title': 'المبتدئ المتميز',
                'description': 'إكمال أول مشروع',
                'icon': '🎯',
                'unlocked_at': user.date_joined.strftime('%Y-%m-%d'),
            })
        
        if enrolled_count >= 3:
            achievements.append({
                'title': 'المتعلم النشط',
                'description': 'إكمال 3 مشاريع',
                'icon': '⭐',
                'unlocked_at': (timezone.now() - timedelta(days=30)).strftime('%Y-%m-%d'),
            })
        
        if enrolled_count >= 5:
            achievements.append({
                'title': 'الخبير الصاعد',
                'description': 'إكمال 5 مشاريع',
                'icon': '🏆',
                'unlocked_at': (timezone.now() - timedelta(days=15)).strftime('%Y-%m-%d'),
            })
        
        return achievements
    
    # ========== دوال مساعدة ثانوية ==========
    
    @staticmethod
    def _calculate_streak_days():
        """حساب الأيام المتتالية - قاعدة عمل"""
        return 7  # قاعدة: أسبوع افتراضي
    
    @staticmethod
    def _determine_skill_level(course_count):
        """تحديد مستوى المهارة - قاعدة عمل"""
        if course_count == 0:
            return 'مبتدئ'
        elif course_count <= 3:
            return 'متوسط'
        elif course_count <= 6:
            return 'متقدّم'
        else:
            return 'خبير'
    
    @staticmethod
    def _calculate_completion_rate(course_count):
        """حساب معدل الإتمام - قاعدة عمل"""
        if course_count == 0:
            return 0
        completed = course_count // 2  # قاعدة: نصف المسارات مكتملة
        return int((completed / course_count) * 100)
    
    @staticmethod
    def _determine_category(course_title):
        """تحديد التصنيف - قاعدة عمل"""
        categories = {
            'ويب': 'تطوير الويب',
            'تطبيق': 'تطوير التطبيقات',
            'بيانات': 'تحليل البيانات',
            'ذكاء': 'الذكاء الاصطناعي',
            'أمن': 'الأمن السيبراني',
            'تصميم': 'تصميم واجهات',
        }
        
        for key, category in categories.items():
            if key in course_title:
                return category
        return 'عام'
    
    @staticmethod
    def _get_skills_for_course(course_title):
        """الحصول على المهارات - قاعدة عمل"""
        skills_map = {
            'ويب': ['HTML', 'CSS', 'JavaScript', 'React'],
            'تطبيق': ['Flutter', 'React Native', 'Android', 'iOS'],
            'بيانات': ['Python', 'Pandas', 'SQL', 'Tableau'],
            'ذكاء': ['Python', 'TensorFlow', 'ML', 'Deep Learning'],
            'mobile': ['Flutter', 'React Native', 'Android', 'iOS'],
            'data': ['Python', 'Pandas', 'SQL', 'Tableau'],
            'ai': ['Python', 'TensorFlow', 'ML', 'Deep Learning'],
        }
        
        course_lower = course_title.lower()
        for key, skills in skills_map.items():
            if key in course_lower:
                return skills
        return ['مهارات تقنية', 'حل المشكلات', 'التفكير النقدي']
    
    @staticmethod
    def _get_notifications():
        """الإشعارات - قاعدة عمل"""
        return [
            {
                'id': 1,
                'title': 'تمت مراجعة مشروعك',
                'message': 'تمت مراجعة مشروع تطوير واجهة المستخدم',
                'type': 'review',
                'timestamp': (timezone.now() - timedelta(hours=2)).isoformat(),
                'read': False,
            },
            {
                'id': 2,
                'title': 'مشروع جديد متاح',
                'message': 'تم إضافة مشروع جديد في مجال الذكاء الاصطناعي',
                'type': 'new_project',
                'timestamp': (timezone.now() - timedelta(days=1)).isoformat(),
                'read': True,
            },
        ]
    
    @staticmethod
    def _get_recent_activity():
        """النشاطات الحديثة - قاعدة عمل"""
        return [
            {
                'id': 1,
                'action': 'بدأ مشروع جديد',
                'project': 'تطوير تطبيق ويب متكامل',
                'timestamp': (timezone.now() - timedelta(hours=1)).isoformat(),
                'icon': '🚀',
            },
            {
                'id': 2,
                'action': 'تم تقديم مشروع',
                'project': 'تحليل بيانات باستخدام Python',
                'timestamp': (timezone.now() - timedelta(days=1)).isoformat(),
                'icon': '📤',
            },
        ]
    
    @staticmethod
    def _get_suggested_projects(courses):
        """المشاريع المقترحة - قاعدة عمل"""
        # جلب المسارات المتاحة التي لم ينضم إليها المتعلم
        enrolled_course_ids = [c.id for c in courses]
        available_courses = Course.objects.filter(
            is_active=True,
            is_public=True
        ).exclude(id__in=enrolled_course_ids)[:3]
        
        suggestions = []
        for i, course in enumerate(available_courses):
            suggestion = {
                'id': course.id,
                'title': course.title,
                'description': course.description[:100] + '...' if len(course.description) > 100 else course.description,
                'category': course.get_category_display(),
                'difficulty': course.get_level_display(),
                'estimated_time': course.estimated_duration,
                'prerequisites': [],
                'match_percentage': 75 - (i * 5),
                'reason': 'مسار متاح للانضمام',
            }
            suggestions.append(suggestion)
        
        return suggestions
    
    @staticmethod
    def _get_quick_actions():
        """الإجراءات السريعة - قاعدة عمل"""
        return [
            {
                'id': 1,
                'title': 'بدء مشروع جديد',
                'icon': '➕',
                'action': 'start_project',
                'description': 'اختر مشروعًا وابدأ العمل',
            },
            {
                'id': 2,
                'title': 'متابعة المشاريع',
                'icon': '📋',
                'action': 'continue_projects',
                'description': 'استكمل مشاريعك النشطة',
            },
        ]