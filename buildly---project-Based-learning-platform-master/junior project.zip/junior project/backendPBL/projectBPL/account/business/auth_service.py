# accounts/business/services/auth_service.py
from django.contrib.auth import authenticate
from django.utils.translation import gettext_lazy as _
from rest_framework_simplejwt.tokens import RefreshToken
from ..data.repositories import UserRepository
from .validation_service import ValidationService
from account.config.admin_config import AdminConfig  # إضافة هذا الاستيراد

class AuthService:
    """خدمات المصادقة - منطق العمل فقط"""
    
    @staticmethod
    def register_learner(email, password, password2):
        """التسجيل الكامل مع كل القواعد"""
        # 1. التحقق من الصحة
        errors = ValidationService.validate_user_data_for_registration(
            email, password, password2
        )
        if errors:
            raise ValueError(errors)
        
        # 2. التحقق من عدم وجود البريد
        if UserRepository.exists_by_email(email):
            raise ValueError({'email': _('البريد الإلكتروني موجود مسبقاً')})
        
        # 3. إنشاء المستخدم
        user = UserRepository.create(
            email=email,
            password=password,
            user_type='learner'
        )
        
        # 4. إنشاء التوكنات
        tokens = AuthService._create_jwt_tokens(user)
        
        # 5. تنسيق النتيجة للعرض
        user_data = AuthService._format_user_for_display(user)
        
        return {
            'user': user,
            'user_data': user_data,
            'tokens': tokens
        }
    
    @staticmethod
    def login(email, password):
        """تسجيل الدخول مع كل القواعد"""
        if not email or not password:
            raise ValueError(_('يجب إدخال البريد الإلكتروني وكلمة المرور'))
        
        # التحقق من صيغة البريد
        if not ValidationService.validate_email_format(email):
            raise ValueError({'email': _('البريد الإلكتروني غير صالح')})
        
        # المصادقة
        user = authenticate(username=email, password=password)
        
        if not user:
            # تحقق إذا كان محاولة دخول بحساب المشرف الثابت
            if AdminConfig.is_admin_email(email):
                raise ValueError(_('بيانات الدخول غير صحيحة للمشرف'))
            else:
                raise ValueError(_('بيانات الدخول غير صحيحة'))
        
        if not user.is_active:
            raise ValueError(_('الحساب غير مفعل'))
        
        # التوكنات
        tokens = AuthService._create_jwt_tokens(user)
        
        # تنسيق النتيجة
        user_data = AuthService._format_user_for_display(user)
        
        return {
            'user': user,
            'user_data': user_data,
            'tokens': tokens
        }
    
    @staticmethod
    def _create_jwt_tokens(user):
        """إنشاء التوكنات - تفاصيل تنفيذية"""
        refresh = RefreshToken.for_user(user)
        return {
            'refresh': str(refresh),
            'access': str(refresh.access_token),
        }
    
    @staticmethod
    def _format_user_for_display(user):
        """تنسيق بيانات المستخدم للعرض - هنا فقط"""
        user_data = {
            'id': user.id,
            'email': user.email,
            'user_type': user.get_user_type_display(),
            'date_joined': user.date_joined,
            'last_login': user.last_login,
        }
        
        if user.is_learner:
            courses = UserRepository.get_learner_courses(user.id)
            user_data.update({
                'enrolled_courses_count': len(courses),
                'enrolled_courses_titles': courses,
            })
        
        return user_data