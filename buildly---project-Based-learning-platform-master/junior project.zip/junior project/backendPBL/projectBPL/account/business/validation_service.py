# accounts/business/services/validation_service.py
from django.core.validators import validate_email
from django.core.exceptions import ValidationError
from django.contrib.auth.password_validation import validate_password
from django.utils.translation import gettext_lazy as _
from account.config.admin_config import AdminConfig  # إضافة هذا الاستيراد

class ValidationService:
    """خدمات التحقق من الصحة فقط"""
    
    @staticmethod
    def validate_email_format(email):
        """التحقق من صيغة البريد فقط"""
        try:
            validate_email(email)
            return True
        except ValidationError:
            return False
    
    @staticmethod
    def validate_password_strength(password):
        """التحقق من قوة كلمة المرور فقط"""
        try:
            validate_password(password)
            return True, []
        except ValidationError as e:
            return False, e.messages
    
    @staticmethod
    def validate_passwords_match(password1, password2):
        """التحقق من تطابق كلمات المرور فقط"""
        return password1 == password2
    
    @staticmethod
    def validate_email_for_registration(email):
        """التحقق من البريد الإلكتروني للتسجيل"""
        errors = {}
        
        if not email:
            errors['email'] = _('البريد الإلكتروني مطلوب')
        elif not ValidationService.validate_email_format(email):
            errors['email'] = _('البريد الإلكتروني غير صالح')
        elif AdminConfig.is_admin_email(email):
            errors['email'] = _('لا يمكن استخدام هذا البريد الإلكتروني')
        
        return errors
    
    @staticmethod
    def validate_user_data_for_registration(email, password, password2):
        """تحقق شامل للبيانات - يعيد الأخطاء إن وجدت"""
        errors = ValidationService.validate_email_for_registration(email)
        
        if not password:
            errors['password'] = _('كلمة المرور مطلوبة')
        else:
            is_valid, password_errors = ValidationService.validate_password_strength(password)
            if not is_valid:
                errors['password'] = password_errors
        
        if not ValidationService.validate_passwords_match(password, password2):
            errors['password2'] = _('كلمات المرور غير متطابقة')
        
        return errors