# from django.contrib import admin
# from .models.user import CustomUser , CustomUserManager
# # Register your models here.
# admin.site.register(CustomUser)
from django.contrib import admin
from .models.user import CustomUser
admin.site.register(CustomUser)
