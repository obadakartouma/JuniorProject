# accounts/data/queries.py
from django.db.models import Count, Q #Q للاستعلامات المعقدة
from datetime import datetime, timedelta
from django.utils import timezone
from ..models.user import CustomUser

class UserQueries:
    """استعلامات معقدة على بيانات المستخدم"""
    
    @staticmethod
    def get_learners_with_courses(min_courses=0):
        """الحصول على المتعلمين مع عدد المسارات"""
        """ الحصول على المتعلمين مع عدد مسارات المنظمين  فيها"""
        return CustomUser.objects.filter(
            user_type='learner'
     #annotate(): إضافة حقل مؤقت إلى كل نتيجة
        ).annotate(
            course_count=Count('enrolled_courses_titles')
        ).filter(
            course_count__gte=min_courses
        ).order_by('-course_count')
    
    @staticmethod
    def get_active_learners(days=30):
        """الحصول على المتعلمين النشطين"""
        date_threshold = timezone.now() - timedelta(days=days)
        return CustomUser.objects.filter(
            user_type='learner',
            last_login__gte=date_threshold
        )
    
    @staticmethod
    def get_learners_by_course(course_title):
        """الحصول على المتعلمين المسجلين في مسار معين"""
        return CustomUser.objects.filter(
            user_type='learner',
            enrolled_courses_titles__contains=[course_title]
        )
    
    @staticmethod
    def get_users_by_type(user_type):
        """الحصول على المستخدمين حسب النوع"""
        return CustomUser.objects.filter(user_type=user_type)
    
    @staticmethod
    def search_users(search_term):
        """بحث في المستخدمين"""
        return CustomUser.objects.filter(
            Q(email__icontains=search_term) |
            Q(first_name__icontains=search_term) |
            Q(last_name__icontains=search_term)
        )