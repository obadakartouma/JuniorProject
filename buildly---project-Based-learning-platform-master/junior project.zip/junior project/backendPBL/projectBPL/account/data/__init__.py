# accounts/data/__init__.py
from .repositories import UserRepository

__all__ = ['UserRepository']