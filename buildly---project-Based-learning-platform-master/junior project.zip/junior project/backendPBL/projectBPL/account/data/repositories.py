# accounts/data/repositories.py
#مسؤول عن عمليات CRUD على البيانات
from django.db import transaction
from courses import models # استيراد نماذج الدورات إذا لزم الأمر
from ..models.user import CustomUser

class UserRepository:
    """فقط عمليات CRUD - لا تحقق من صحة"""
    
    @staticmethod
    def get_by_id(user_id):
        try:
            return CustomUser.objects.get(id=user_id)
        except CustomUser.DoesNotExist:
            return None
    
    @staticmethod
    def get_by_email(email):
        try:
            return CustomUser.objects.get(email=email)
        except CustomUser.DoesNotExist:
            return None
    
    @staticmethod
    def exists_by_email(email):
        """فقط يخبر إذا كان موجوداً - لا يرفع أخطاء"""
        return CustomUser.objects.filter(email=email).exists()
    
    @staticmethod
    def create(email, password=None, **extra_fields):
        """إنشاء فقط - يفترض البيانات صحيحة"""
        return CustomUser.objects.create_user(
            email=email, 
            password=password, 
            **extra_fields
        )
    
    @staticmethod
    def update(user_id, **update_fields):
        """تحديث فقط"""
        user = CustomUser.objects.get(id=user_id)
        for field, value in update_fields.items():
            setattr(user, field, value)
        user.save()
        return user
    
    @staticmethod
    def add_course_to_learner(user_id, course_title):
        """إضافة مسار - تفاصيل تنفيذية فقط"""
        with transaction.atomic():
            user = CustomUser.objects.get(id=user_id)
            if user.enrolled_courses_titles is None:
                user.enrolled_courses_titles = []
            
            if course_title not in user.enrolled_courses_titles:
                user.enrolled_courses_titles.append(course_title)
                user.save()
                return True
            return False
    
    @staticmethod
    def get_learner_courses(user_id):
        """جلب مسارات المتعلم"""
        user = CustomUser.objects.get(id=user_id)
        return user.enrolled_courses_titles or []
    
    # ❌❌❌ محذوف: validate_email, email_exists مع raise

class UserQueries:
    """استعلامات فقط - لا معالجة"""
    @staticmethod
    def get_learners_with_min_courses(min_courses=0):
        return CustomUser.objects.filter(
            user_type='learner',
            enrolled_courses_titles__isnull=False
        ).annotate(
             course_count=models.Count('enrolled_courses_titles')
        ).filter(course_count__gte=min_courses)