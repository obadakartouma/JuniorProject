import axiosInstance from "./axiosInstance";

export const fetchUsersApi = () => {
  return axiosInstance.get("/users");
};
