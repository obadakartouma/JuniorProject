import api from '../utils/axiosConfig'

// Account APIs
export const accountAPI = {
  login: (email, password) =>
    api.post('/account/login/', { email, password }),

  registerLearner: (email, password, password2) =>
    api.post('/account/register/learner/', { email, password, password2 }),

  logout: (refreshToken) =>
    api.post('/account/logout/', { refresh_token: refreshToken }),

  getProfile: () =>
    api.get('/account/profile/'),

  updateProfile: (data) =>
    api.patch('/account/profile/', data),

  getLearnerDashboard: () =>
    api.get('/account/learner/dashboard/'),

  getLearnerProgress: () =>
    api.get('/account/learner/progress/'),
}

