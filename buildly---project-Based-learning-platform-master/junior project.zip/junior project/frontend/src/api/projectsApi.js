import api from '../utils/axiosConfig'

// Projects APIs
export const projectsAPI = {
  list: (courseId = null) => {
    const params = courseId ? { course_id: courseId } : {}
    return api.get('/projects/', { params })
  },

  get: (id) =>
    api.get(`/projects/${id}/`),

  create: (data) =>
    api.post('/projects/create/', data),

  update: (id, data) =>
    api.put(`/projects/${id}/update/`, data),

  delete: (id) =>
    api.delete(`/projects/${id}/delete/`),

  confirmDelete: (id) =>
    api.get(`/projects/${id}/confirm-delete/`),

  getByCourse: (courseId) =>
    api.get(`/projects/course/${courseId}/`),

  start: (id) =>
    api.post(`/projects/${id}/start/`),
}

