import api from '../utils/axiosConfig'

// Courses APIs
export const coursesAPI = {
  list: () =>
    api.get('/courses/'),

  get: (id) =>
    api.get(`/courses/${id}/`),

  getDetails: (id) =>
    api.get(`/courses/${id}/details/`),

  create: (data) =>
    api.post('/courses/create/', data),

  update: (id, data) =>
    api.put(`/courses/${id}/update/`, data),

  delete: (id) =>
    api.delete(`/courses/${id}/delete/`),

  confirmDelete: (id) =>
    api.get(`/courses/${id}/confirm-delete/`),

  join: (id) =>
    api.post(`/courses/${id}/join/`),

  checkEnrollment: (id) =>
    api.get(`/courses/${id}/check-enrollment/`),

  myCourses: () =>
    api.get('/courses/my-courses/'),
}

