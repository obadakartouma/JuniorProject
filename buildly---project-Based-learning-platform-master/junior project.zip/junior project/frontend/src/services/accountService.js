import { accountAPI } from '../api/accountApi'

export const accountService = {
  login: async (email, password) => {
    try {
      const response = await accountAPI.login(email, password)
      const { user: userData, tokens } = response.data

      localStorage.setItem('access_token', tokens.access)
      localStorage.setItem('refresh_token', tokens.refresh)
      localStorage.setItem('user', JSON.stringify(userData))

      return { success: true, data: response.data }
    } catch (error) {
      return {
        success: false,
        error: error.response?.data || { message: 'حدث خطأ أثناء تسجيل الدخول' },
      }
    }
  },

  register: async (email, password, password2, userType = 'learner') => {
    try {
      // فقط تسجيل المتعلمين متاح
      if (userType === 'admin') {
        return {
          success: false,
          error: { message: 'تسجيل المشرفين غير متاح من خلال الواجهة' }
        }
      }

      const response = await accountAPI.registerLearner(email, password, password2)
      const { user: userData, tokens } = response.data

      localStorage.setItem('access_token', tokens.access)
      localStorage.setItem('refresh_token', tokens.refresh)
      localStorage.setItem('user', JSON.stringify(userData))

      return { success: true, data: response.data }
    } catch (error) {
      return {
        success: false,
        error: error.response?.data || { message: 'حدث خطأ أثناء التسجيل' },
      }
    }
  },

  logout: async () => {
    try {
      const refreshToken = localStorage.getItem('refresh_token')
      if (refreshToken) {
        await accountAPI.logout(refreshToken)
      }
    } catch (error) {
      console.error('Logout error:', error)
    } finally {
      localStorage.removeItem('access_token')
      localStorage.removeItem('refresh_token')
      localStorage.removeItem('user')
    }
  },

  getProfile: async () => {
    try {
      const response = await accountAPI.getProfile()
      return { success: true, data: response.data }
    } catch (error) {
      return {
        success: false,
        error: error.response?.data || { message: 'فشل تحميل الملف الشخصي' },
      }
    }
  },

  updateProfile: async (data) => {
    try {
      const response = await accountAPI.updateProfile(data)
      return { success: true, data: response.data }
    } catch (error) {
      return {
        success: false,
        error: error.response?.data || { message: 'فشل تحديث الملف الشخصي' },
      }
    }
  },

  getLearnerDashboard: async () => {
    try {
      const response = await accountAPI.getLearnerDashboard()
      return { success: true, data: response.data }
    } catch (error) {
      return {
        success: false,
        error: error.response?.data || { message: 'فشل تحميل لوحة التحكم' },
      }
    }
  },

  getLearnerProgress: async () => {
    try {
      const response = await accountAPI.getLearnerProgress()
      return { success: true, data: response.data }
    } catch (error) {
      return {
        success: false,
        error: error.response?.data || { message: 'فشل تحميل التقدم' },
      }
    }
  },
}

