import { projectsAPI } from '../api/projectsApi'

export const projectsService = {
  list: async (courseId = null) => {
    try {
      const response = await projectsAPI.list(courseId)
      return { success: true, data: response.data }
    } catch (error) {
      return {
        success: false,
        error: error.response?.data || { message: 'فشل تحميل المشاريع' },
      }
    }
  },

  get: async (id) => {
    try {
      const response = await projectsAPI.get(id)
      return { success: true, data: response.data }
    } catch (error) {
      return {
        success: false,
        error: error.response?.data || { message: 'فشل تحميل المشروع' },
      }
    }
  },

  create: async (data) => {
    try {
      const response = await projectsAPI.create(data)
      return { success: true, data: response.data }
    } catch (error) {
      return {
        success: false,
        error: error.response?.data || { message: 'فشل إنشاء المشروع' },
      }
    }
  },

  update: async (id, data) => {
    try {
      const response = await projectsAPI.update(id, data)
      return { success: true, data: response.data }
    } catch (error) {
      return {
        success: false,
        error: error.response?.data || { message: 'فشل تحديث المشروع' },
      }
    }
  },

  delete: async (id) => {
    try {
      const response = await projectsAPI.delete(id)
      return { success: true, data: response.data }
    } catch (error) {
      return {
        success: false,
        error: error.response?.data || { message: 'فشل حذف المشروع' },
      }
    }
  },

  confirmDelete: async (id) => {
    try {
      const response = await projectsAPI.confirmDelete(id)
      return { success: true, data: response.data }
    } catch (error) {
      return {
        success: false,
        error: error.response?.data || { message: 'فشل التحقق من الحذف' },
      }
    }
  },

  getByCourse: async (courseId) => {
    try {
      const response = await projectsAPI.getByCourse(courseId)
      return { success: true, data: response.data }
    } catch (error) {
      return {
        success: false,
        error: error.response?.data || { message: 'فشل تحميل مشاريع المسار' },
      }
    }
  },

  start: async (id) => {
    try {
      const response = await projectsAPI.start(id)
      return { success: true, data: response.data }
    } catch (error) {
      return {
        success: false,
        error: error.response?.data || { message: 'فشل بدء المشروع' },
      }
    }
  },
}

