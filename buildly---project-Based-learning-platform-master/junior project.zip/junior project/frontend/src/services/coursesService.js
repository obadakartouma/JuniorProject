import { coursesAPI } from '../api/coursesApi'

export const coursesService = {
  list: async () => {
    try {
      const response = await coursesAPI.list()
      return { success: true, data: response.data }
    } catch (error) {
      return {
        success: false,
        error: error.response?.data || { message: 'فشل تحميل المسارات' },
      }
    }
  },

  get: async (id) => {
    try {
      const response = await coursesAPI.get(id)
      return { success: true, data: response.data }
    } catch (error) {
      return {
        success: false,
        error: error.response?.data || { message: 'فشل تحميل المسار' },
      }
    }
  },

  getDetails: async (id) => {
    try {
      const response = await coursesAPI.getDetails(id)
      return { success: true, data: response.data }
    } catch (error) {
      return {
        success: false,
        error: error.response?.data || { message: 'فشل تحميل تفاصيل المسار' },
      }
    }
  },

  create: async (data) => {
    try {
      const response = await coursesAPI.create(data)
      return { success: true, data: response.data }
    } catch (error) {
      return {
        success: false,
        error: error.response?.data || { message: 'فشل إنشاء المسار' },
      }
    }
  },

  update: async (id, data) => {
    try {
      const response = await coursesAPI.update(id, data)
      return { success: true, data: response.data }
    } catch (error) {
      return {
        success: false,
        error: error.response?.data || { message: 'فشل تحديث المسار' },
      }
    }
  },

  delete: async (id) => {
    try {
      const response = await coursesAPI.delete(id)
      return { success: true, data: response.data }
    } catch (error) {
      return {
        success: false,
        error: error.response?.data || { message: 'فشل حذف المسار' },
      }
    }
  },

  confirmDelete: async (id) => {
    try {
      const response = await coursesAPI.confirmDelete(id)
      return { success: true, data: response.data }
    } catch (error) {
      return {
        success: false,
        error: error.response?.data || { message: 'فشل التحقق من الحذف' },
      }
    }
  },

  join: async (id) => {
    try {
      const response = await coursesAPI.join(id)
      return { success: true, data: response.data }
    } catch (error) {
      return {
        success: false,
        error: error.response?.data || { message: 'فشل الانضمام للمسار' },
      }
    }
  },

  checkEnrollment: async (id) => {
    try {
      const response = await coursesAPI.checkEnrollment(id)
      return { success: true, data: response.data }
    } catch (error) {
      return {
        success: false,
        error: error.response?.data || { message: 'فشل التحقق من التسجيل' },
      }
    }
  },

  myCourses: async () => {
    try {
      const response = await coursesAPI.myCourses()
      return { success: true, data: response.data }
    } catch (error) {
      return {
        success: false,
        error: error.response?.data || { message: 'فشل تحميل مساراتي' },
      }
    }
  },
}

