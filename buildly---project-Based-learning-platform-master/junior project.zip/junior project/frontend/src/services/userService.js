import { fetchUsersApi } from "../api/userApi";

export const getUsers = async () => {
  const response = await fetchUsersApi();
  return response.data;


  // business rule example
  const activeUsers = response.data.filter(
    (user) => user.isActive
  );

  return activeUsers;
};
