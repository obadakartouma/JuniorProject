import React, { createContext, useState, useEffect, useContext } from 'react'
import { accountService } from '../services/accountService'

const AuthContext = createContext()

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)
  const [isAuthenticated, setIsAuthenticated] = useState(false)

  useEffect(() => {
    // تحميل بيانات المستخدم من localStorage
    const storedUser = localStorage.getItem('user')
    const accessToken = localStorage.getItem('access_token')

    if (storedUser && accessToken) {
      try {
        const userData = JSON.parse(storedUser)
        setUser(userData)
        setIsAuthenticated(true)
      } catch (error) {
        console.error('Error parsing user data:', error)
        localStorage.removeItem('user')
        localStorage.removeItem('access_token')
        localStorage.removeItem('refresh_token')
      }
    }

    setLoading(false)
  }, [])

  const login = async (email, password) => {
    const result = await accountService.login(email, password)
    if (result.success) {
      const userData = result.data.user
      setUser(userData)
      setIsAuthenticated(true)
    }
    return result
  }

  const register = async (email, password, password2, userType = 'learner') => {
    const result = await accountService.register(email, password, password2, userType)
    if (result.success) {
      const userData = result.data.user
      setUser(userData)
      setIsAuthenticated(true)
    }
    return result
  }

  const logout = async () => {
    await accountService.logout()
    setUser(null)
    setIsAuthenticated(false)
  }

  const updateUser = (userData) => {
    setUser(userData)
    localStorage.setItem('user', JSON.stringify(userData))
  }

  const value = {
    user,
    loading,
    isAuthenticated,
    login,
    register,
    logout,
    updateUser,
    // ✅ التحقق من is_admin/is_learner أولاً، ثم user_type كبديل
    isAdmin: user?.is_admin === true || user?.user_type === 'admin' || user?.user_type === 'مشرف',
    isLearner: user?.is_learner === true || user?.user_type === 'learner' || user?.user_type === 'متعلم',
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

